import { useState } from 'react';
import { Link } from 'react-router-dom';
import Button from '../components/Button';
import './CapabilityPage.css'; // Shared Design
import { Icons } from '../assets/icons';

const certificates = [
    {
        id: 'iso9001',
        name: 'ISO 9001:2015',
        desc: 'Kalite Yönetim Sistemi. Tüm süreçlerde sürekli iyileştirme güvencesi.',
        icon: Icons.precision // or similar
    },
    {
        id: 'iso45001',
        name: 'ISO 45001:2018',
        desc: 'İş Sağlığı ve Güvenliği Yönetim Sistemi. Güvenli çalışma ortamı güvencesi.',
        icon: Icons.aerospace
    },
    {
        id: 'iso14001',
        name: 'ISO 14001:2015',
        desc: 'Çevre Yönetim Sistemi. Çevresel etkileri minimize eden sürdürülebilir üretim.',
        icon: Icons.medical
    }
];

const inspectionSteps = [
    { step: '01', title: 'Giriş Kontrol', text: 'Hammadde sertifikaları ve malzeme analizlerine göre gelen malzeme kontrolü yapılır.' },
    { step: '02', title: 'Proses Kontrol', text: 'Üretim sırasında operatör ve kalite teknisyenleri tarafından ara ölçümler (SPC) yapılır.' },
    { step: '03', title: 'Raporlama', text: 'Bitmiş parçalar görsel ve boyutsal kontrolden geçer. FAI raporu hazırlanır.' }
];

const metrologyEquipment = [
    { label: 'CMM', value: 'Hexagon Global S (1.3 µm Hassasiyet)' },
    { label: 'Profil Projeksiyon', value: 'Mitutoyo Optik Ölçüm (3 µm)' },
    { label: 'Yüzey Pürüzlülük', value: 'Mitutoyo SJ-210 (Ra 0.01 µm)' },
    { label: 'Yükseklik Mihengiri', value: 'Dijital 600mm (5 µm)' },
    { label: 'Sertlik Ölçümü', value: 'Rockwell & Brinell Test Cihazları' },
    { label: 'Spektral Analiz', value: 'Oxford Instruments (Kimyasal Analiz)' }
];

function QualityPage() {
    return (
        <div className="cnc-machining-page">
            {/* Hero */}
            <section style={{
                background: 'var(--color-dark-bg)',
                color: 'white',
                padding: '100px 0 60px',
                textAlign: 'center'
            }}>
                <div className="container">
                    <h1 style={{ fontSize: '3rem', marginBottom: '16px', color: 'white' }}>Kalite Kontrol & Sertifikasyon</h1>
                    <p style={{ fontSize: '1.25rem', opacity: 0.8, maxWidth: '700px', margin: '0 auto' }}>
                        Uluslararası standartlara tam uyum ile doğrulanabilir kalite süreçleri ve %100 izlenebilirlik.
                    </p>
                </div>
            </section>

            {/* Certificates */}
            <section className="section bg-white">
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Standartlar</span>
                        <h2>Sertifikalarımız</h2>
                        <div className="header-line"></div>
                        <p>Küresel endüstri standartlarına uygun üretim yeteneği.</p>
                    </div>
                    <div className="capabilities-info">
                        {certificates.map(cert => (
                            <div key={cert.id} className="capability-card" data-aos="fade-up">
                                <div className="cap-card-bg"></div>
                                <div className="capability-icon" style={{ color: '#059669', background: 'rgba(5, 150, 105, 0.1)' }}>{cert.icon || Icons.precision}</div>
                                <h3>{cert.name}</h3>
                                <p>{cert.desc}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Inspection Process */}
            <section className="section bg-soft process-modern">
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Süreç</span>
                        <h2>Denetim Süreci</h2>
                        <div className="header-line"></div>
                        <p>Hammadde girişinden final kontrole titiz takip.</p>
                    </div>
                    <div className="process-full-width">
                        <div className="process-timeline-v3">
                            {inspectionSteps.map((item, idx) => (
                                <div key={idx} className="process-step-full">
                                    <div className="step-number-v3" style={{ color: '#059669' }}>{item.step}</div>
                                    <div className="step-content-v3">
                                        <h3>{item.title}</h3>
                                        <p>{item.text}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </section>

            {/* Footer CTA */}
            <section className="section cnc-footer-cta">
                <div className="cta-glass-box">
                    <div className="cta-content-inner">
                        <span className="badge-outline" style={{ borderColor: '#059669', color: '#059669' }}>Kalite Raporu</span>
                        <h2>Numune raporu ve sertifikalarımızı inceleyin.</h2>
                        <p>Kalite süreçlerimiz hakkında detaylı bilgi almak için bizimle iletişime geçin.</p>
                        <Button href="/teklif-al" variant="primary" size="lg" className="btn-no-hover-color" style={{ borderColor: '#059669', backgroundColor: '#059669' }}>Numune İsteyin</Button>
                    </div>
                </div>
            </section>
        </div>
    );
}

export default QualityPage;
