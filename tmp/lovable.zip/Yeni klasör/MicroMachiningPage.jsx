import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../components/Button';
import { Icons } from '../assets/icons';
import './CapabilityPage.css';

const MicroMachiningPage = () => {
    return (
        <div className="cnc-machining-page">
            {/* 1. Hero Section */}
            <section style={{
                background: 'var(--color-dark-bg)',
                color: 'white',
                padding: '100px 0 60px',
                textAlign: 'center'
            }}>
                <div className="container">
                    <h1 style={{ fontSize: '3rem', marginBottom: '16px', color: 'white' }}>Hassas Mikro İşleme</h1>
                    <p style={{ fontSize: '1.25rem', opacity: 0.8, maxWidth: '700px', margin: '0 auto' }}>
                        Milimetrenin altında toleranslarla, mikron seviyesinde hassasiyet gerektiren parçalar için özel çözümler.
                    </p>
                </div>
            </section>

            {/* 2. Capabilities Grid */}
            <section className="section bg-white">
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Teknolojiler</span>
                        <h2>Mikro İşleme Kabiliyetleri</h2>
                        <div className="header-line"></div>
                        <p>Saat, medikal ve elektronik endüstrisi standartlarında üretim.</p>
                    </div>

                    <div className="capabilities-info">
                        <div className="capability-card" data-aos="fade-up">
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.precision || '🎯'}</div>
                            <h3>Mikro Frezeleme</h3>
                            <p>Ø0.1 mm'ye kadar takımlarla 5 eksen mikro frezeleme. Optik, elektronik ve medikal implant parçaları.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.1s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.cncTurning || '🔩'}</div>
                            <h3>Mikro Tornalama</h3>
                            <p>Ø0.3 mm'den başlayan çaplarda Swiss tornalama. Saat pimi, medikal vida ve konektör pinleri.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.2s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.laserCutting || '💡'}</div>
                            <h3>Mikro Delme</h3>
                            <p>Ø0.05 mm'ye kadar hassas delik delme. Enjektör uçları, nozullar ve akış kontrol parçaları.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.3s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.processControl || '📊'}</div>
                            <h3>Mikro Ölçüm</h3>
                            <p>Optik ölçüm cihazları ve CMM ile mikron seviyesinde kalite kontrol. Ölçüm raporları ve sertifikalar.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* 3. Specs Section */}
            <section className="specs-section">
                <div className="specs-decor-line"></div>
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Teknik Özellikler</span>
                        <h2>Mikro İşleme Kapasitesi</h2>
                        <div className="header-line"></div>
                        <p>Hassas mikro işleme için özel ekipman ve standartlarımız.</p>
                    </div>

                    <div className="specs-dashboard">
                        <div className="specs-grid-v2">
                            <div className="spec-item">
                                <span className="spec-label">Minimum Takım Çapı</span>
                                <span className="spec-value">Ø0.1 mm (Frezeleme), Ø0.05 mm (Delme)</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Tolerans</span>
                                <span className="spec-value">±0.002 mm (2 mikron) hassasiyet</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Yüzey Kalitesi</span>
                                <span className="spec-value">Ra 0.1 μm'ye kadar (ayna parlaklığı)</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">İş Mili Hızı</span>
                                <span className="spec-value">60.000 RPM'e kadar yüksek hızlı iş mili</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Parça Boyutu</span>
                                <span className="spec-value">1 mm³'den 100 mm³'e kadar mikro parçalar</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Ölçüm Hassasiyeti</span>
                                <span className="spec-value">0.1 μm çözünürlüklü optik ölçüm</span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* 4. Materials Mini Section */}
            <section className="section bg-soft">
                <div className="container">
                    <div className="materials-layout">
                        <div className="materials-content">
                            <span className="section-subtitle">Malzemeler</span>
                            <h2 style={{ marginBottom: '24px', fontSize: '2rem', color: 'var(--color-dark)' }}>Mikro İşleme Malzemeleri</h2>
                            <p style={{ marginBottom: '32px', fontSize: '1.1rem', lineHeight: '1.6' }}>
                                Hassas mikro işleme için özellikle seçilmiş, homojen yapılı malzemeler kullanıyoruz.
                            </p>
                            <Link to="/malzemeler" className="btn-text-arrow">
                                Tüm Malzeme Listesi {Icons.arrowRight}
                            </Link>
                        </div>
                        <div className="materials-tags-cloud">
                            {['Titanyum Grade 5', 'Paslanmaz 316L (Medikal)', 'Alüminyum 7075', 'Bakır C101', 'Pirinç C360', 'PEEK', 'PTFE', 'Seramik', 'Tungsten Karbür', 'Kobalt Krom'].map((mat, i) => (
                                <span key={i} className="material-tag-v2">{mat}</span>
                            ))}
                        </div>
                    </div>
                </div>
            </section>

            {/* 5. Industries Section */}
            <section className="section">
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Endüstriler</span>
                        <h2>Mikro İşleme Uygulama Alanları</h2>
                        <div className="header-line"></div>
                    </div>
                    <div className="capabilities-info">
                        <div className="capability-card">
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.medical || '🏥'}</div>
                            <h3>Medikal</h3>
                            <p>İmplantlar, cerrahi aletler, kemik vidaları, stentler ve mikro akışkan cihazları.</p>
                        </div>
                        <div className="capability-card">
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.aerospace || '✈️'}</div>
                            <h3>Havacılık</h3>
                            <p>Yakıt enjektörleri, sensör muhafazaları, mikro valfler ve hassas bağlantı elemanları.</p>
                        </div>
                        <div className="capability-card">
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.robotics || '🤖'}</div>
                            <h3>Elektronik</h3>
                            <p>Konektör pinleri, fiber optik bileşenler, yarı iletken test aparatları.</p>
                        </div>
                        <div className="capability-card">
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.delivery || '⌚'}</div>
                            <h3>Saat & Optik</h3>
                            <p>Saat mekanizma parçaları, lens tutucular, kamera bileşenleri.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* 6. FAQ Section */}
            <section className="section faq-modern">
                <div className="container">
                    <div className="section-header text-center">
                        <h2>Sık Sorulan Sorular</h2>
                    </div>
                    <div className="faq-grid-v2">
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Mikro işleme ne zaman tercih edilmeli?</h4>
                            <p>Parça özellikleri 1 mm altında veya toleranslar ±0.01 mm altında ise mikro işleme gereklidir. Standart CNC bu hassasiyetlere ulaşamaz.</p>
                        </div>
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Maliyet standart CNC'den yüksek mi?</h4>
                            <p>Evet, özel takımlar, yavaş ilerleme hızları ve hassas ölçüm gereksinimleri nedeniyle maliyet daha yüksektir. Ancak bu, standart yöntemlerle elde edilemeyecek sonuçlar içindir.</p>
                        </div>
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Seri üretim yapabiliyor musunuz?</h4>
                            <p>Evet, otomatik besleyicili Swiss torna ve palletli 5 eksen sistemleri ile mikro parçalarda bile seri üretim yapabiliyoruz.</p>
                        </div>
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Ölçüm raporu veriyor musunuz?</h4>
                            <p>Her mikro parça optik veya CMM ile ölçülür. AS9100/ISO 13485 uyumlu ölçüm raporları ve sertifikalar sağlıyoruz.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* 7. Footer CTA */}
            <section className="section cnc-footer-cta">
                <div className="cta-glass-box">
                    <div className="cta-content-inner">
                        <span className="badge-outline">Mikro İşleme</span>
                        <h2>Mikron Hassasiyetinde Üretim</h2>
                        <p>CAD dosyanızı ve tolerans gereksinimlerinizi gönderin, üretilebilirlik analizi yapalım.</p>
                        <Button href="/teklif-al" variant="primary" size="lg" className="btn-no-hover-color">Hemen Teklif Al</Button>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default MicroMachiningPage;
