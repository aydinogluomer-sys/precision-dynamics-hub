import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../components/Button';
import { Icons } from '../assets/icons';
import './CapabilityPage.css';

const CncMillingPage = () => {
    return (
        <div className="cnc-machining-page">
            {/* 1. Hero Section */}
            <section style={{
                background: 'var(--color-dark-bg)',
                color: 'white',
                padding: '100px 0 60px',
                textAlign: 'center'
            }}>
                <div className="container">
                    <h1 style={{ fontSize: '3rem', marginBottom: '16px', color: 'white' }}>CNC Frezeleme</h1>
                    <p style={{ fontSize: '1.25rem', opacity: 0.8, maxWidth: '700px', margin: '0 auto' }}>
                        3, 4 ve 5 eksen CNC frezeleme ile karmaşık geometrileri yüksek hassasiyetle üretiyoruz.
                    </p>
                </div>
            </section>

            {/* 2. Capabilities Grid */}
            <section className="section bg-white">
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Teknolojiler</span>
                        <h2>Frezeleme Kabiliyetlerimiz</h2>
                        <div className="header-line"></div>
                        <p>Farklı eksen konfigürasyonları ile her türlü geometriyi işliyoruz.</p>
                    </div>

                    <div className="capabilities-info">
                        <div className="capability-card" data-aos="fade-up">
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.cncMilling || '🔧'}</div>
                            <h3>3 Eksen Frezeleme</h3>
                            <p>Düz yüzeyler, cep işleme ve standart geometriler için ekonomik çözüm. Büyük tablalı makinelerde 1500x800mm'ye kadar parça.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.1s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.precision || '🎯'}</div>
                            <h3>4 Eksen Frezeleme</h3>
                            <p>Döner tabla ile çevresel işlemler. Silindirik parçalarda kanal açma, delik delme ve profil işleme.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.2s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.production || '⚙️'}</div>
                            <h3>5 Eksen Frezeleme</h3>
                            <p>Tek bağlamada karmaşık geometriler. Havacılık, medikal ve otomotiv için yüksek hassasiyetli parçalar.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.3s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.delivery || '⏱️'}</div>
                            <h3>Yüksek Hızlı İşleme (HSM)</h3>
                            <p>40.000 RPM'e kadar iş mili hızı ile ince cidarlı parçalar ve hassas yüzey kalitesi.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* 3. Specs Section */}
            <section className="specs-section">
                <div className="specs-decor-line"></div>
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Teknik Özellikler</span>
                        <h2>Frezeleme Kapasitesi</h2>
                        <div className="header-line"></div>
                        <p>CNC frezeleme merkezlerimizin teknik özellikleri.</p>
                    </div>

                    <div className="specs-dashboard">
                        <div className="specs-grid-v2">
                            <div className="spec-item">
                                <span className="spec-label">Maksimum Parça Boyutu</span>
                                <span className="spec-value">1500 x 800 x 600 mm (3 eksen), 800 x 500 x 500 mm (5 eksen)</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Tolerans</span>
                                <span className="spec-value">±0.005 mm'ye kadar hassasiyet</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Yüzey Kalitesi</span>
                                <span className="spec-value">Ra 0.4 μm'ye kadar (işlenmiş yüzey)</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">İş Mili Hızı</span>
                                <span className="spec-value">12.000 - 40.000 RPM (makineye göre)</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Takım Kapasitesi</span>
                                <span className="spec-value">30-120 takım magazini (otomatik değiştirici)</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Malzemeler</span>
                                <span className="spec-value">Alüminyum, Çelik, Paslanmaz, Titanyum, Pirinç, Plastikler</span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* 4. Materials Mini Section */}
            <section className="section bg-soft">
                <div className="container">
                    <div className="materials-layout">
                        <div className="materials-content">
                            <span className="section-subtitle">Malzemeler</span>
                            <h2 style={{ marginBottom: '24px', fontSize: '2rem', color: 'var(--color-dark)' }}>İşlenebilir Malzemeler</h2>
                            <p style={{ marginBottom: '32px', fontSize: '1.1rem', lineHeight: '1.6' }}>
                                CNC frezeleme ile metalden plastiğe geniş bir malzeme yelpazesi işleyebiliyoruz.
                            </p>
                            <Link to="/malzemeler" className="btn-text-arrow">
                                Tüm Malzeme Listesi {Icons.arrowRight}
                            </Link>
                        </div>
                        <div className="materials-tags-cloud">
                            {['Alüminyum 6061-T6', 'Alüminyum 7075', 'Paslanmaz Çelik 304/316', 'Çelik 1045', 'Titanyum Grade 5', 'Pirinç C360', 'Bakır C101', 'Delrin (POM)', 'PEEK', 'Nylon'].map((mat, i) => (
                                <span key={i} className="material-tag-v2">{mat}</span>
                            ))}
                        </div>
                    </div>
                </div>
            </section>

            {/* 5. FAQ Section */}
            <section className="section faq-modern">
                <div className="container">
                    <div className="section-header text-center">
                        <h2>Sık Sorulan Sorular</h2>
                    </div>
                    <div className="faq-grid-v2">
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>3 eksen mi 5 eksen mi kullanmalıyım?</h4>
                            <p>Düz yüzeyler ve basit cep işlemleri için 3 eksen yeterlidir. Alttan kesim, eğik yüzeyler veya tek bağlamada çok yüzey işleme gerekiyorsa 5 eksen tercih edilir.</p>
                        </div>
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Minimum sipariş adedi var mı?</h4>
                            <p>Hayır, tek parçadan seri üretime kadar her adette üretim yapıyoruz. Prototip siparişleri de kabul ediyoruz.</p>
                        </div>
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Teslim süresi ne kadar?</h4>
                            <p>Standart parçalarda 5-10 iş günü. Ekspres üretimde 2 iş gününe kadar inebiliyoruz.</p>
                        </div>
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Hangi dosya formatlarını kabul ediyorsunuz?</h4>
                            <p>STEP, IGES, Parasolid, SolidWorks, Inventor ve Fusion 360 dosyaları. 2D çizim için PDF veya DXF.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* 6. Footer CTA */}
            <section className="section cnc-footer-cta">
                <div className="cta-glass-box">
                    <div className="cta-content-inner">
                        <span className="badge-outline">CNC Frezeleme</span>
                        <h2>Projeniz İçin Teklif Alın</h2>
                        <p>CAD dosyanızı yükleyin, 24 saat içinde detaylı teklif ve DFM analizi alın.</p>
                        <Button href="/teklif-al" variant="primary" size="lg" className="btn-no-hover-color">Hemen Teklif Al</Button>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default CncMillingPage;
