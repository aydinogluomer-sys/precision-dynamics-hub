import { useState } from 'react';
import { Link } from 'react-router-dom';
import Button from '../components/Button';
import Card from '../components/Card';
import ImageCompareSlider from '../components/ImageCompareSlider';
import './SurfaceFinishPage.css';
import './CapabilityPage.css';
import { Icons } from '../assets/icons';

// Surface finishes data (Preserved)
const surfaceFinishes = [
    {
        id: 'as-machined',
        name: 'İşlenmiş Yüzey (As Machined)',
        category: 'standard',
        description: 'CNC işleme sonrası standart yüzey. Takım izleri görülebilir ancak fonksiyonel parçalar için uygundur.',
        roughness: '1.6 µm Ra',
        thicknessChange: 'Değişim yok',
        durability: 3,
        aesthetics: 2,
        cost: 1,
        leadTime: '0 gün ek süre',
        compatibleMaterials: ['Alüminyum', 'Çelik', 'Titanyum', 'Pirinç', 'Plastikler'],
        applications: ['Prototip', 'İç parçalar', 'Fonksiyonel test'],
        pros: ['En ekonomik', 'En hızlı teslimat', 'Boyutsal doğruluk korunur'],
        cons: ['Takım izleri görünür', 'Korozyon koruması yok'],
        colorGradient: 'linear-gradient(135deg, #9CA3AF 0%, #6B7280 100%)',
        beforeTexture: 'machined',
        afterTexture: 'machined',
        afterColor: '#6B7280'
    },
    {
        id: 'bead-blasting',
        name: 'Kumlama (Bead Blasting)',
        category: 'mechanical',
        description: 'Cam boncuklarla püskürtme ile ünifor mat yüzey. Takım izlerini gizler ve homojen görünüm sağlar.',
        roughness: '1.6-6.3 µm Ra',
        thicknessChange: '< 0.05 mm',
        durability: 3,
        aesthetics: 4,
        cost: 2,
        leadTime: '+1 gün',
        compatibleMaterials: ['Alüminyum', 'Çelik', 'Paslanmaz Çelik', 'Titanyum'],
        applications: ['Tüketici elektroniği', 'Medikal cihazlar', 'Endüstriyel ekipman'],
        pros: ['Ünifor mat görünüm', 'Takım izlerini gizler', 'Ekonomik'],
        cons: ['Korozyon koruması sağlamaz', 'Yüzey dokusu kalıcı değişir'],
        colorGradient: 'linear-gradient(135deg, #D1D5DB 0%, #9CA3AF 100%)',
        beforeTexture: 'machined',
        afterTexture: 'bead-blasted',
        afterColor: '#9CA3AF'
    },
    {
        id: 'anodize-type2',
        name: 'Anodize Tip II (Dekoratif)',
        category: 'chemical',
        description: 'Elektrokimyasal oksit tabakası oluşturma. Korozyon direnci ve geniş renk seçeneği sunar.',
        roughness: '0.8-1.6 µm Ra',
        thicknessChange: '+5-25 µm (dışa)',
        durability: 4,
        aesthetics: 5,
        cost: 3,
        leadTime: '+2-3 gün',
        compatibleMaterials: ['Alüminyum', 'Titanyum'],
        applications: ['Tüketici ürünleri', 'Havacılık', 'Otomotiv'],
        colors: ['Şeffaf', 'Siyah', 'Kırmızı', 'Mavi', 'Altın', 'Yeşil'],
        pros: ['Korozyon direnci', 'Geniş renk seçeneği', 'Aşınma direnci artışı'],
        cons: ['Sadece Alüminyum/Titanyum', 'Boyutlar değişir', 'İletkenliği azaltır'],
        colorGradient: 'linear-gradient(135deg, #3B82F6 0%, #1D4ED8 100%)',
        beforeTexture: 'machined',
        afterTexture: 'anodized',
        afterColor: '#3B82F6'
    },
    {
        id: 'anodize-type3',
        name: 'Anodize Tip III (Hardcoat)',
        category: 'chemical',
        description: 'Kalın ve sert oksit tabakası. Yüksek aşınma direnci gerektiren kritik parçalar için.',
        roughness: '1.6-3.2 µm Ra',
        thicknessChange: '+25-75 µm',
        durability: 5,
        aesthetics: 3,
        cost: 4,
        leadTime: '+3-4 gün',
        compatibleMaterials: ['Alüminyum'],
        applications: ['Havacılık', 'Savunma', 'Hidrolik sistemler', 'Aşınma yüzeyleri'],
        colors: ['Doğal gri-siyah'],
        pros: ['En yüksek aşınma direnci', 'Yüksek sertlik (60-70 HRC)', 'Kimyasal direnç'],
        cons: ['Sınırlı renk', 'Daha pahalı', 'Yorulma dayanımını azaltabilir'],
        colorGradient: 'linear-gradient(135deg, #374151 0%, #1F2937 100%)',
        beforeTexture: 'machined',
        afterTexture: 'anodized',
        afterColor: '#374151'
    },
    {
        id: 'powder-coating',
        name: 'Toz Boya (Powder Coating)',
        category: 'coating',
        description: 'Elektrostatik toz boya uygulaması ve fırınlama. Dayanıklı, kalın koruyucu tabaka.',
        roughness: '2.0-5.0 µm Ra',
        thicknessChange: '+50-150 µm',
        durability: 5,
        aesthetics: 5,
        cost: 3,
        leadTime: '+2-3 gün',
        compatibleMaterials: ['Alüminyum', 'Çelik', 'Paslanmaz Çelik'],
        applications: ['Dış mekan ekipmanları', 'Otomotiv', 'Mobilya', 'Muhafazalar'],
        colors: ['RAL renk kataloğu - 200+ seçenek'],
        pros: ['En geniş renk yelpazesi', 'Mükemmel darbe direnci', 'UV dayanımı'],
        cons: ['Kalın tabaka - toleransları etkiler', 'Vida dişleri maskelenmeli', 'Yüksek sıcaklık işlemi'],
        colorGradient: 'linear-gradient(135deg, #10B981 0%, #059669 100%)',
        beforeTexture: 'machined',
        afterTexture: 'powder-coated',
        afterColor: '#10B981'
    },
    {
        id: 'electroplating-nickel',
        name: 'Nikel Kaplama',
        category: 'plating',
        description: 'Elektrolizle nikel tabakası oluşturma. Korozyon direnci ve dekoratif parlak görünüm.',
        roughness: '0.2-0.8 µm Ra',
        thicknessChange: '+5-25 µm',
        durability: 4,
        aesthetics: 5,
        cost: 4,
        leadTime: '+3-4 gün',
        compatibleMaterials: ['Çelik', 'Bakır', 'Pirinç', 'Alüminyum (özel işlem)'],
        applications: ['Dekoratif parçalar', 'Elektrik kontakları', 'Aşınma yüzeyleri'],
        pros: ['Parlak metalik görünüm', 'İyi korozyon direnci', 'Lehimlenebilir'],
        cons: ['Çevre düzenlemeleri', 'Hidrojen kırılganlığı riski', 'Ön işlem gerektirir'],
        colorGradient: 'linear-gradient(135deg, #E5E7EB 0%, #9CA3AF 100%)',
        beforeTexture: 'machined',
        afterTexture: 'polished',
        afterColor: '#E5E7EB'
    },
    {
        id: 'electroplating-chrome',
        name: 'Krom Kaplama',
        category: 'plating',
        description: 'Dekoratif veya sert krom kaplama. Ayna parlaklığı ve üstün aşınma direnci.',
        roughness: '0.1-0.4 µm Ra',
        thicknessChange: '+0.5-50 µm',
        durability: 5,
        aesthetics: 5,
        cost: 5,
        leadTime: '+4-5 gün',
        compatibleMaterials: ['Çelik', 'Alüminyum (özel)', 'Bakır alaşımları'],
        applications: ['Otomotiv parçaları', 'Hidrolik pistonlar', 'Kalıp yüzeyleri'],
        pros: ['En düşük sürtünme', 'Ayna parlaklığı', 'Yüksek sertlik'],
        cons: ['En pahalı', 'Çevre düzenlemeleri sıkı', 'Uzun işlem süresi'],
        colorGradient: 'linear-gradient(135deg, #F3F4F6 0%, #D1D5DB 100%)',
        beforeTexture: 'machined',
        afterTexture: 'chrome',
        afterColor: '#F3F4F6'
    },
    {
        id: 'blackening',
        name: 'Siyah Oksit (Burnishing)',
        category: 'chemical',
        description: 'Çelik yüzeyinde ince siyah oksit tabakası. Boyutları etkilemeden korozyon direnci.',
        roughness: 'Değişmez',
        thicknessChange: '< 1 µm',
        durability: 2,
        aesthetics: 4,
        cost: 2,
        leadTime: '+1-2 gün',
        compatibleMaterials: ['Karbon Çeliği', 'Alaşımlı Çelik'],
        applications: ['Bağlantı elemanları', 'Dişliler', 'Takım tutucular'],
        pros: ['Boyutları değiştirmez', 'Ekonomik', 'Estetik siyah görünüm'],
        cons: ['Sınırlı korozyon koruması', 'Yağlama gerektirir', 'Sadece çelik'],
        colorGradient: 'linear-gradient(135deg, #1F2937 0%, #111827 100%)',
        beforeTexture: 'machined',
        afterTexture: 'blackened',
        afterColor: '#1F2937'
    },
    {
        id: 'passivation',
        name: 'Pasivasyon',
        category: 'chemical',
        description: 'Paslanmaz çelik için krom oksit tabakasını güçlendirme. Korozyon direncini artırır.',
        roughness: 'Değişmez',
        thicknessChange: '< 1 µm',
        durability: 4,
        aesthetics: 2,
        cost: 2,
        leadTime: '+1 gün',
        compatibleMaterials: ['Paslanmaz Çelik'],
        applications: ['Medikal cihazlar', 'Gıda işleme', 'Kimya sanayi'],
        pros: ['Korozyon direnci artışı', 'Boyutları değiştirmez', 'FDA/Medikal uyum'],
        cons: ['Görsel değişiklik yok', 'Sadece paslanmaz çelik', 'Serfifikasyon gerekebilir'],
        colorGradient: 'linear-gradient(135deg, #6B7280 0%, #4B5563 100%)',
        beforeTexture: 'machined',
        afterTexture: 'machined',
        afterColor: '#6B7280'
    },
    {
        id: 'polishing',
        name: 'Parlatma (Polishing)',
        category: 'mechanical',
        description: 'Mekanik parlatma ile ayna yüzey elde etme. En düşük pürüzlülük değerleri.',
        roughness: '0.05-0.4 µm Ra',
        thicknessChange: '-5 ile -50 µm',
        durability: 2,
        aesthetics: 5,
        cost: 4,
        leadTime: '+2-4 gün',
        compatibleMaterials: ['Alüminyum', 'Paslanmaz Çelik', 'Çelik', 'Bakır', 'Pirinç'],
        applications: ['Optik parçalar', 'Kalıp yüzeyleri', 'Dekoratif ürünler'],
        pros: ['Ayna parlaklığı', 'Hijyenik yüzey', 'En düşük sürtünme'],
        cons: ['Zaman alıcı', 'Koruyucu kaplama gerektirir', 'Malzeme kaldırır'],
        colorGradient: 'linear-gradient(135deg, #FAFAFA 0%, #E5E7EB 100%)',
        beforeTexture: 'machined',
        afterTexture: 'polished',
        afterColor: '#FAFAFA'
    }
];

// Categories for filtering
const categories = [
    { id: 'all', label: 'Tümü' },
    { id: 'standard', label: 'Standart' },
    { id: 'mechanical', label: 'Mekanik' },
    { id: 'chemical', label: 'Kimyasal' },
    { id: 'coating', label: 'Kaplama' },
    { id: 'plating', label: 'Galvanik' }
];

// Rating component
const Rating = ({ value, max = 5, label }) => (
    <div className="sf-rating">
        <span className="sf-rating-label">{label}</span>
        <div className="sf-rating-stars">
            {[...Array(max)].map((_, i) => (
                <span key={i} className={`sf-star ${i < value ? 'filled' : ''}`}>★</span>
            ))}
        </div>
    </div>
);

function SurfaceFinishPage() {
    const [activeCategory, setActiveCategory] = useState('all');
    const [selectedFinish, setSelectedFinish] = useState(null);
    const [compareMode, setCompareMode] = useState(false);
    const [compareList, setCompareList] = useState([]);

    // Filter finishes
    const filteredFinishes = activeCategory === 'all'
        ? surfaceFinishes
        : surfaceFinishes.filter(f => f.category === activeCategory);

    // Toggle compare
    const toggleCompare = (finish) => {
        if (compareList.find(f => f.id === finish.id)) {
            setCompareList(compareList.filter(f => f.id !== finish.id));
        } else if (compareList.length < 3) {
            setCompareList([...compareList, finish]);
        }
    };

    return (
        <div className="cnc-machining-page">
            {/* 1. Simple Hero Section */}
            <section style={{
                background: 'var(--color-dark-bg)',
                color: 'white',
                padding: '100px 0 60px',
                textAlign: 'center'
            }}>
                <div className="container">
                    <h1 style={{ fontSize: '3rem', marginBottom: '16px', color: 'white' }}>Yüzey İşlemleri</h1>
                    <p style={{ fontSize: '1.25rem', opacity: 0.8, maxWidth: '700px', margin: '0 auto' }}>
                        Parçalarınız için optimum koruma, estetik ve fonksiyonellik sunan geniş yüzey işlem yelpazesi.
                    </p>
                </div>
            </section>

            {/* 2. Main Capabilities (Sub-sets) */}
            <section className="section bg-white">
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Kategoriler</span>
                        <h2>İşlem Türleri</h2>
                        <div className="header-line"></div>
                        <p>Endüstriyel standartlarda yüzey iyileştirme çözümleri.</p>
                    </div>

                    <div className="capabilities-info">
                        <div className="capability-card">
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.anodizing || '⬡'}</div>
                            <h3>Anodizasyon</h3>
                            <p>Alüminyum ve Titanyum için Tip II (Renkli) ve Tip III (Hardcoat) eloksal işlemleri. Korozyon ve aşınma direnci.</p>
                        </div>
                        <div className="capability-card">
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.chemistry || '🧪'}</div>
                            <h3>Kimyasal İşlemler</h3>
                            <p>Paslanmaz çelik için Pasivasyon, çelikler için Siyah Oksit ve Alüminyum için Kromatlama (Alodine).</p>
                        </div>
                        <div className="capability-card">
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.cncMachining || '🛡️'}</div>
                            <h3>Mekanik Yüzeyler</h3>
                            <p>Kumlama (Bead Blasting), Tesviye, Polisaj ve Fırçalama ile istenilen yüzey pürüzlülüğü (Ra) değerleri.</p>
                        </div>
                        <div className="capability-card">
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.painting || '🎨'}</div>
                            <h3>Boya ve Kaplama</h3>
                            <p>Elektrostatik Toz Boya (Powder Coating), Yaş Boya ve Seramik Kaplama (Cerakote) seçenekleri.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* 3. Surface Finish Gallery & Filters */}
            <section className="sf-filters" style={{ borderTop: '1px solid var(--color-border)', marginTop: 0, paddingTop: '60px' }}>
                <div className="container">
                    <div className="section-header text-center">
                        <h2>Yüzey İşlem Rehberi</h2>
                        <p>Detaylı teknik özellikler ve karşılaştırma.</p>
                    </div>

                    {/* Info Bar Compact */}
                    <div className="sf-info-bar" style={{ marginBottom: '30px', background: 'var(--color-soft-bg)' }}>
                        <div className="info-items">
                            <div className="info-item">
                                <span className="info-icon">⚠️</span>
                                <span>Yüzey işlemleri parça boyutlarını değiştirebilir.</span>
                            </div>
                        </div>
                    </div>

                    <div className="filter-row">
                        <div className="filter-buttons">
                            {categories.map(cat => (
                                <button
                                    key={cat.id}
                                    className={`filter-btn ${activeCategory === cat.id ? 'active' : ''}`}
                                    onClick={() => setActiveCategory(cat.id)}
                                >
                                    {cat.label}
                                </button>
                            ))}
                        </div>
                        <button
                            className={`compare-toggle ${compareMode ? 'active' : ''}`}
                            onClick={() => {
                                setCompareMode(!compareMode);
                                if (!compareMode) setCompareList([]);
                            }}
                        >
                            {compareMode ? '✕ Karşılaştırmayı Kapat' : '⚖️ Karşılaştır'}
                        </button>
                    </div>

                    {/* Compare bar */}
                    {compareMode && compareList.length > 0 && (
                        <div className="compare-bar">
                            <span>Seçilen ({compareList.length}/3):</span>
                            {compareList.map(f => (
                                <span key={f.id} className="compare-chip">
                                    {f.name}
                                    <button onClick={() => toggleCompare(f)}>×</button>
                                </span>
                            ))}
                            {compareList.length >= 2 && (
                                <Button
                                    variant="primary"
                                    size="sm"
                                    onClick={() => setSelectedFinish('compare')}
                                >
                                    Karşılaştır
                                </Button>
                            )}
                        </div>
                    )}
                </div>
            </section>

            {/* 4. Gallery Grid */}
            <section className="sf-gallery section" style={{ paddingTop: '20px' }}>
                <div className="container">
                    <div className="sf-grid">
                        {filteredFinishes.map(finish => (
                            <div
                                key={finish.id}
                                className={`sf-card ${compareMode && compareList.find(f => f.id === finish.id) ? 'selected' : ''}`}
                            >
                                {/* Visual Preview */}
                                <div
                                    className="sf-preview"
                                    style={{ background: finish.colorGradient }}
                                >
                                    <div className="sf-preview-overlay">
                                        <span className="sf-category-badge">{
                                            categories.find(c => c.id === finish.category)?.label
                                        }</span>
                                    </div>
                                </div>

                                {/* Content */}
                                <div className="sf-content">
                                    <h3>{finish.name}</h3>
                                    <p className="sf-desc">{finish.description}</p>

                                    <div className="sf-specs">
                                        <div className="sf-spec">
                                            <span className="sf-spec-label">Pürüzlülük</span>
                                            <span className="sf-spec-value">{finish.roughness}</span>
                                        </div>
                                        <div className="sf-spec">
                                            <span className="sf-spec-label">Ek Süre</span>
                                            <span className="sf-spec-value">{finish.leadTime}</span>
                                        </div>
                                    </div>

                                    <div className="sf-actions">
                                        <button
                                            className="sf-btn detail"
                                            onClick={() => setSelectedFinish(finish)}
                                        >
                                            Detayları Gör
                                        </button>
                                        {compareMode && (
                                            <button
                                                className={`sf-btn compare ${compareList.find(f => f.id === finish.id) ? 'active' : ''}`}
                                                onClick={() => toggleCompare(finish)}
                                                disabled={!compareList.find(f => f.id === finish.id) && compareList.length >= 3}
                                            >
                                                {compareList.find(f => f.id === finish.id) ? '✓' : '+'}
                                            </button>
                                        )}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Detail Modal */}
            {selectedFinish && selectedFinish !== 'compare' && (
                <div className="modal-overlay" onClick={() => setSelectedFinish(null)}>
                    <div className="modal-content sf-modal" onClick={e => e.stopPropagation()}>
                        <button className="modal-close" onClick={() => setSelectedFinish(null)}>×</button>

                        <div
                            className="sf-modal-header"
                            style={!selectedFinish.beforeTexture ? { background: selectedFinish.colorGradient } : { padding: 0, background: 'transparent' }}
                        >
                            {selectedFinish.beforeTexture ? (
                                <div className="sf-modal-slider-wrapper">
                                    <ImageCompareSlider
                                        beforeTexture={selectedFinish.beforeTexture}
                                        afterTexture={selectedFinish.afterTexture}
                                        afterColor={selectedFinish.afterColor}
                                        beforeLabel="İşlenmiş"
                                        afterLabel={selectedFinish.name.split('(')[0]}
                                    />
                                    <div className="sf-modal-header-content">
                                        <span className="sf-category-badge">
                                            {categories.find(c => c.id === selectedFinish.category)?.label}
                                        </span>
                                        <h2>{selectedFinish.name}</h2>
                                    </div>
                                </div>
                            ) : (
                                <>
                                    <span className="sf-category-badge">
                                        {categories.find(c => c.id === selectedFinish.category)?.label}
                                    </span>
                                    <h2>{selectedFinish.name}</h2>
                                </>
                            )}
                        </div>

                        <div className="sf-modal-body">
                            <p className="sf-modal-desc">{selectedFinish.description}</p>

                            <div className="sf-modal-grid">
                                <div className="sf-modal-section">
                                    <h4>Teknik Özellikler</h4>
                                    <table className="sf-specs-table">
                                        <tbody>
                                            <tr><td>Yüzey Pürüzlülüğü (Ra)</td><td>{selectedFinish.roughness}</td></tr>
                                            <tr><td>Kalınlık Değişimi</td><td>{selectedFinish.thicknessChange}</td></tr>
                                            <tr><td>Ek Teslim Süresi</td><td>{selectedFinish.leadTime}</td></tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div className="sf-modal-section">
                                    <h4>Performans</h4>
                                    <Rating value={selectedFinish.durability} label="Dayanıklılık" />
                                    <Rating value={selectedFinish.aesthetics} label="Estetik" />
                                    <Rating value={selectedFinish.cost} label="Maliyet" />
                                </div>
                            </div>

                            <div className="sf-modal-footer">
                                <Button href="/teklif-al" variant="primary">Bu İşlemle Teklif Al</Button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Compare Modal */}
            {selectedFinish === 'compare' && compareList.length >= 2 && (
                <div className="modal-overlay" onClick={() => setSelectedFinish(null)}>
                    <div className="modal-content compare-modal" onClick={e => e.stopPropagation()}>
                        <button className="modal-close" onClick={() => setSelectedFinish(null)}>×</button>
                        <h2>Yüzey İşlem Karşılaştırması</h2>
                        <div className="compare-table-wrapper">
                            <table className="compare-table">
                                <thead>
                                    <tr>
                                        <th>Özellik</th>
                                        {compareList.map(f => <th key={f.id}>{f.name}</th>)}
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr><td>Pürüzlülük</td>{compareList.map(f => <td key={f.id}>{f.roughness}</td>)}</tr>
                                    <tr><td>Dayanıklılık</td>{compareList.map(f => <td key={f.id}>{'★'.repeat(f.durability)}</td>)}</tr>
                                    <tr><td>Maliyet</td>{compareList.map(f => <td key={f.id}>{'$'.repeat(f.cost)}</td>)}</tr>
                                </tbody>
                            </table>
                        </div>
                        <div className="modal-footer">
                            <Button variant="outline" onClick={() => setSelectedFinish(null)}>Kapat</Button>
                            <Button href="/teklif-al" variant="primary">Teklif Al</Button>
                        </div>
                    </div>
                </div>
            )}

            {/* 5. Footer CTA */}
            <section className="section cnc-footer-cta">
                <div className="cta-glass-box">
                    <div className="cta-content-inner">
                        <span className="badge-outline">Yüzey Rehberi</span>
                        <h2>Kararsız mı kaldınız?</h2>
                        <p>Kullanım alanınıza en uygun yüzey işlemini belirlemek için uzmanlarımızdan destek alın.</p>
                        <Button href="/teklif-al" variant="primary" size="lg" className="btn-no-hover-color">Uzman Desteği Al</Button>
                    </div>
                </div>
            </section>
        </div>
    );
}

export default SurfaceFinishPage;
