import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../components/Button';
import { Icons } from '../assets/icons';
import './CapabilityPage.css';

const MarkingPage = () => {
    return (
        <div className="cnc-machining-page">
            {/* 1. Hero Section */}
            <section style={{
                background: 'var(--color-dark-bg)',
                color: 'white',
                padding: '100px 0 60px',
                textAlign: 'center'
            }}>
                <div className="container">
                    <h1 style={{ fontSize: '3rem', marginBottom: '16px', color: 'white' }}>İşaretleme & Tanımlama</h1>
                    <p style={{ fontSize: '1.25rem', opacity: 0.8, maxWidth: '700px', margin: '0 auto' }}>
                        Ürün izlenebilirliği için kalıcı lazer markalama ve kazıma çözümleri.
                    </p>
                </div>
            </section>

            {/* 2. Capabilities Grid */}
            <section className="section bg-white">
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Teknolojiler</span>
                        <h2>Lazer İşaretleme Çözümleri</h2>
                        <div className="header-line"></div>
                        <p>Fiber lazer teknolojisi ile hızlı, hassas ve kalıcı markalama.</p>
                    </div>

                    <div className="capabilities-info">
                        <div className="capability-card" data-aos="fade-up">
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.laserCutting || '🔦'}</div>
                            <h3>Lazer Kazıma</h3>
                            <p>Metal yüzeylerde derinlemesine kazıma ile silinmez, fiziksel derinliğe sahip işaretleme. Zorlu koşullara dayanıklıdır.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.1s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.sun || '☀️'}</div>
                            <h3>Tavlama</h3>
                            <p>Yüzeyden malzeme kaldırmadan, ısıyla renk değiştirerek yapılan pürüzsüz işaretleme. Özellikle paslanmaz ve medikal için.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.2s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.qrCode || '📱'}</div>
                            <h3>QR & DataMatrix</h3>
                            <p>Endüstriyel standartlarda (UDI, GS1, MIL-STD) izlenebilirlik sağlayan yüksek kontrastlı karekod ve barkod uygulamaları.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.3s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.scan || '🆔'}</div>
                            <h3>Logo & Markalama</h3>
                            <p>Marka kimliğinizi ürün üzerine yüksek çözünürlükle işleme. Vektörel logolar ve grafikler için mükemmel detay.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* 3. Specs Section */}
            <section className="specs-section">
                <div className="specs-decor-line"></div>
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Teknik Özellikler</span>
                        <h2>Markalama Kapasitesi</h2>
                        <div className="header-line"></div>
                        <p>Endüstriyel fiber lazer sistemlerimizle sunduğumuz standartlar.</p>
                    </div>

                    <div className="specs-dashboard">
                        <div className="specs-grid-v2">
                            <div className="spec-item">
                                <span className="spec-label">Markalama Alanı</span>
                                <span className="spec-value">300mm x 300mm'ye kadar tek seferde işlem.</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Hassasiyet</span>
                                <span className="spec-value">±0.001 mm tekrarlanabilirlik ve pozisyonlama.</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Lazer Tipi</span>
                                <span className="spec-value">Fiber Lazer (20W - 50W), MOPA Lazer (Renkli ve siyah işaretleme).</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Derinlik</span>
                                <span className="spec-value">0.01mm - 0.5mm (Kazıma derinliği ayarlanabilir).</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Hız</span>
                                <span className="spec-value">7000 mm/sn'ye kadar yüksek hızlı markalama.</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Uyumlu Malzemeler</span>
                                <span className="spec-value">Tüm metaller (Çelik, Alüminyum, Titanyum) ve bazı plastikler.</span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* 4. Materials Mini Section */}
            <section className="section bg-soft">
                <div className="container">
                    <div className="materials-layout">
                        <div className="materials-content">
                            <span className="section-subtitle">Malzemeler</span>
                            <h2 style={{ marginBottom: '24px', fontSize: '2rem', color: 'var(--color-dark)' }}>Hangi Malzemeler İşaretlenebilir?</h2>
                            <p style={{ marginBottom: '32px', fontSize: '1.1rem', lineHeight: '1.6' }}>
                                Fiber lazer teknolojisi, metaller üzerinde mükemmel sonuç verirken, belirli plastik türlerinde de kontrast oluşturabilir.
                            </p>
                            <Link to="/malzemeler" className="btn-text-arrow">
                                Tüm Malzeme Listesi {Icons.arrowRight}
                            </Link>
                        </div>
                        <div className="materials-tags-cloud">
                            {['Alüminyum (Tüm Alaşımlar)', 'Paslanmaz Çelik', 'Karbon Çeliği', 'Titanyum', 'Pirinç & Bakır', 'Nikel Kaplama', 'Sert Plastikler (ABS, PC)', 'Anodize Yüzeyler', 'Boyalı Metaller'].map((mat, i) => (
                                <span key={i} className="material-tag-v2">{mat}</span>
                            ))}
                        </div>
                    </div>
                </div>
            </section>

            {/* 5. FAQ Section */}
            <section className="section faq-modern">
                <div className="container">
                    <div className="section-header text-center">
                        <h2>Sık Sorulan Sorular</h2>
                    </div>
                    <div className="faq-grid-v2">
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Markalama kalıcı mıdır?</h4>
                            <p>Evet, lazer kazıma ve annealing işlemleri kalıcıdır. Kimyasallara, aşınmaya ve yüksek sıcaklıklara karşı dayanıklıdır.</p>
                        </div>
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Renkli markalama yapabiliyor musunuz?</h4>
                            <p>MOPA lazer teknolojimiz ile paslanmaz çelik üzerinde belirli renk tonlarını elde edebiliyoruz. Diğer malzemelerde genellikle siyah/beyaz/gri tonları oluşur.</p>
                        </div>
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Seri numarası takibi yapılıyor mu?</h4>
                            <p>Evet, yazılımımız otomatik artan seri numaraları, tarih kodları ve veritabanı bağlantılı dinamik içerikleri işleyebilir.</p>
                        </div>
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Numune çalışması yapıyor musunuz?</h4>
                            <p>Evet, malzemenizi gönderdiğinizde ücretsiz numune markalama çalışması yapıp size geri gönderiyoruz.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* 6. Footer CTA */}
            <section className="section cnc-footer-cta">
                <div className="cta-glass-box">
                    <div className="cta-content-inner">
                        <span className="badge-outline">İzlenebilirlik</span>
                        <h2>Ürünlerinizi Kalıcı Hale Getirin</h2>
                        <p>Parça başına maliyetleri düşüren hızlı ve kalıcı markalama çözümlerimizle tanışın.</p>
                        <Button href="/teklif-al" variant="primary" size="lg" className="btn-no-hover-color">Hemen Teklif Al</Button>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default MarkingPage;
