import { Link } from 'react-router-dom';
import { Icons } from '../assets/icons';
import './ServicesPage.css';

// Using a similar structure to CapabilitiesPage for consistency
const services = [
    {
        title: 'CNC İşleme',
        description: 'Talaşlı imalat yöntemleriyle yüksek hassasiyetli parça üretimi. 3, 4 ve 5 eksen frezeleme ve tornalama çözümleri.',
        icon: Icons.cncMilling,
        path: '/hizmetler/talasli-imalat',
        color: '#2563EB' // Blue
    },
    {
        title: 'Ön Üretim & Şekillendirme',
        description: 'Kalıp, döküm ve ilk şekillendirme operasyonları. Enjeksiyon ve basınçlı döküm kalıpları.',
        icon: Icons.casting,
        path: '/hizmetler/on-uretim',
        color: '#D97706' // Orange
    },
    {
        title: 'Yüzey İşlemleri',
        description: 'Parçaların yüzey kalitesini ve dayanıklılığını artıran eloksal, kaplama ve kumlama işlemleri.',
        icon: Icons.processControl, // Using processControl as a proxy for surface treatment
        path: '/hizmetler/yuzey-islemleri',
        color: '#059669' // Green
    },
    {
        title: 'İşaretleme & Tanımlama',
        description: 'Ürün izlenebilirliği için kalıcı işaretleme çözümleri. Lazer markalama ve seri numarası işleme.',
        icon: Icons.laserCutting,
        path: '/hizmetler/isaretleme',
        color: '#7C3AED' // Purple
    },
    {
        title: 'Montaj & Sonlandırma',
        description: 'Ürünlerin montajı, temizliği, paketlenmesi ve sevkiyata hazır hale getirilmesi süreçleri.',
        icon: Icons.production,
        path: '/hizmetler/montaj',
        color: '#DC2626' // Red
    },
    {
        title: 'Kalite Kontrol',
        description: 'CMM ölçümleri ve detaylı raporlama ile üretim kalitesinin doğrulanması.',
        icon: Icons.check,
        path: '/hizmetler/kalite-kontrol',
        color: '#0891B2' // Cyan
    }
];

function ServicesPage() {
    return (
        <div className="services-page">
            <section style={{
                background: 'var(--color-dark-bg)', color: 'white', padding: '100px 0 60px', textAlign: 'center'
            }}>
                <div className="container">
                    <h1 style={{ fontSize: '3rem', marginBottom: '16px', color: 'white' }}>Hizmetlerimiz</h1>
                    <p style={{ fontSize: '1.25rem', opacity: 0.8, maxWidth: '700px', margin: '0 auto' }}>
                        Endüstriyel üretim süreçlerinizin her aşamasında yanınızdayız.
                    </p>
                </div>
            </section>

            <section className="section">
                <div className="container">
                    <div style={{
                        display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))', gap: '32px'
                    }}>
                        {services.map((item, index) => (
                            <Link
                                key={index}
                                to={item.path}
                                style={{
                                    display: 'block', textDecoration: 'none', background: 'var(--color-white)',
                                    padding: '32px', borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)',
                                    transition: 'transform 0.3s ease, box-shadow 0.3s ease'
                                }}
                                onMouseEnter={(e) => {
                                    e.currentTarget.style.transform = 'translateY(-5px)';
                                    e.currentTarget.style.boxShadow = 'var(--shadow-xl)';
                                }}
                                onMouseLeave={(e) => {
                                    e.currentTarget.style.transform = 'translateY(0)';
                                    e.currentTarget.style.boxShadow = 'none';
                                }}
                            >
                                <div style={{
                                    width: '64px', height: '64px', borderRadius: '16px', background: `${item.color}20`,
                                    color: item.color, display: 'flex', alignItems: 'center', justifyContent: 'center',
                                    marginBottom: '24px'
                                }}>
                                    {item.icon || <span style={{ fontSize: '24px' }}>🔧</span>}
                                </div>
                                <h3 style={{ fontSize: '1.5rem', color: 'var(--color-heading)', marginBottom: '12px' }}>
                                    {item.title}
                                </h3>
                                <p style={{ color: 'var(--color-body)', lineHeight: 1.6, margin: 0 }}>
                                    {item.description}
                                </p>
                                <div style={{ marginTop: '20px', color: item.color, fontWeight: 600, fontSize: '0.9375rem' }}>
                                    Detaylı Bilgi &rarr;
                                </div>
                            </Link>
                        ))}
                    </div>
                </div>
            </section>

            {/* Quick CTA */}
            <section className="start-analysis-cta" style={{ padding: '60px 0', background: 'var(--color-soft-bg)', textAlign: 'center' }}>
                <div className="container">
                    <h2 style={{ marginBottom: '16px' }}>Özel bir üretim talebiniz mi var?</h2>
                    <p style={{ marginBottom: '32px', color: 'var(--color-body)' }}>
                        teknik ekibimizle iletişime geçin, projenize en uygun yöntemi belirleyelim.
                    </p>
                    <Link to="/teklif-al" className="btn btn-primary btn-lg">
                        Hemen Teklif Al
                    </Link>
                </div>
            </section>
        </div>
    );
}

export default ServicesPage;
