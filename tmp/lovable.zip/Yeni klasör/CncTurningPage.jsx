import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../components/Button';
import { Icons } from '../assets/icons';
import './CapabilityPage.css';

const CncTurningPage = () => {
    return (
        <div className="cnc-machining-page">
            {/* 1. Hero Section */}
            <section style={{
                background: 'var(--color-dark-bg)',
                color: 'white',
                padding: '100px 0 60px',
                textAlign: 'center'
            }}>
                <div className="container">
                    <h1 style={{ fontSize: '3rem', marginBottom: '16px', color: 'white' }}>CNC Tornalama</h1>
                    <p style={{ fontSize: '1.25rem', opacity: 0.8, maxWidth: '700px', margin: '0 auto' }}>
                        Silindirik ve dönme simetrisine sahip parçalar için hassas CNC torna çözümleri.
                    </p>
                </div>
            </section>

            {/* 2. Capabilities Grid */}
            <section className="section bg-white">
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Teknolojiler</span>
                        <h2>Tornalama Kabiliyetlerimiz</h2>
                        <div className="header-line"></div>
                        <p>Basit millerden karmaşık turn-mill parçalarına kadar geniş yetenek.</p>
                    </div>

                    <div className="capabilities-info">
                        <div className="capability-card" data-aos="fade-up">
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.cncTurning || '🔩'}</div>
                            <h3>2 Eksen Tornalama</h3>
                            <p>Miller, burçlar ve basit silindirik parçalar. Büyük çaplı parçalarda 500mm çapa kadar işleme.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.1s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.precision || '🎯'}</div>
                            <h3>Canlı Takımlı Tornalama</h3>
                            <p>Y ekseni ve canlı takım ile torna tezgahında frezeleme, delme ve diş açma işlemleri.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.2s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.production || '⚙️'}</div>
                            <h3>Turn-Mill (Torna-Freze)</h3>
                            <p>Tek bağlamada hem tornalama hem frezeleme. Karmaşık parçalarda yüksek hassasiyet ve verimlilik.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.3s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.delivery || '⏱️'}</div>
                            <h3>Swiss Tornalama</h3>
                            <p>Küçük çaplı, uzun parçalar için kayar punta teknolojisi. Medikal ve saat endüstrisi standartlarında.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* 3. Specs Section */}
            <section className="specs-section">
                <div className="specs-decor-line"></div>
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Teknik Özellikler</span>
                        <h2>Tornalama Kapasitesi</h2>
                        <div className="header-line"></div>
                        <p>CNC torna tezgahlarımızın teknik özellikleri.</p>
                    </div>

                    <div className="specs-dashboard">
                        <div className="specs-grid-v2">
                            <div className="spec-item">
                                <span className="spec-label">Maksimum Çap</span>
                                <span className="spec-value">Ø500 mm (standart), Ø32 mm (Swiss torna)</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Maksimum Boy</span>
                                <span className="spec-value">1000 mm (standart), 300 mm (Swiss torna)</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Tolerans</span>
                                <span className="spec-value">±0.005 mm'ye kadar hassasiyet</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Yüzey Kalitesi</span>
                                <span className="spec-value">Ra 0.4 μm'ye kadar (işlenmiş yüzey)</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Canlı Takım</span>
                                <span className="spec-value">12 istasyonlu revolver, Y ekseni ±50mm</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Bar Besleyici</span>
                                <span className="spec-value">Ø65 mm'ye kadar otomatik çubuk besleme</span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* 4. Materials Mini Section */}
            <section className="section bg-soft">
                <div className="container">
                    <div className="materials-layout">
                        <div className="materials-content">
                            <span className="section-subtitle">Malzemeler</span>
                            <h2 style={{ marginBottom: '24px', fontSize: '2rem', color: 'var(--color-dark)' }}>Tornalama Malzemeleri</h2>
                            <p style={{ marginBottom: '32px', fontSize: '1.1rem', lineHeight: '1.6' }}>
                                Çubuk malzemeden plaka kesime kadar farklı ham madde formlarında çalışıyoruz.
                            </p>
                            <Link to="/malzemeler" className="btn-text-arrow">
                                Tüm Malzeme Listesi {Icons.arrowRight}
                            </Link>
                        </div>
                        <div className="materials-tags-cloud">
                            {['Alüminyum 6061', 'Alüminyum 2024', 'Paslanmaz Çelik 303/304', 'Otomat Çeliği', 'Titanyum', 'Pirinç', 'Bronz', 'Delrin (POM)', 'PTFE', 'Nylon'].map((mat, i) => (
                                <span key={i} className="material-tag-v2">{mat}</span>
                            ))}
                        </div>
                    </div>
                </div>
            </section>

            {/* 5. FAQ Section */}
            <section className="section faq-modern">
                <div className="container">
                    <div className="section-header text-center">
                        <h2>Sık Sorulan Sorular</h2>
                    </div>
                    <div className="faq-grid-v2">
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Tornalama mı frezeleme mi seçmeliyim?</h4>
                            <p>Parçanız silindirik veya dönme simetrisine sahipse tornalama daha ekonomiktir. Prizmatik parçalar için frezeleme tercih edilir.</p>
                        </div>
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Karmaşık parçalar tek tezgahta mı yapılır?</h4>
                            <p>Turn-mill tezgahlarımızda hem tornalama hem frezeleme işlemleri tek bağlamada yapılabilir. Bu hassasiyeti artırır ve maliyeti düşürür.</p>
                        </div>
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Swiss tornalama ne zaman gerekir?</h4>
                            <p>Ø32 mm altı çaplarda ve boy/çap oranı yüksek parçalarda (örn: medikal vidalar, pimler) Swiss torna daha hassas sonuç verir.</p>
                        </div>
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Seri üretim için uygun mu?</h4>
                            <p>Evet, bar besleyicili tezgahlarımızda gece-gündüz kesintisiz seri üretim yapabiliyoruz.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* 6. Footer CTA */}
            <section className="section cnc-footer-cta">
                <div className="cta-glass-box">
                    <div className="cta-content-inner">
                        <span className="badge-outline">CNC Tornalama</span>
                        <h2>Torna Parçanız İçin Teklif Alın</h2>
                        <p>CAD dosyanızı yükleyin, 24 saat içinde detaylı teklif ve DFM analizi alın.</p>
                        <Button href="/teklif-al" variant="primary" size="lg" className="btn-no-hover-color">Hemen Teklif Al</Button>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default CncTurningPage;
