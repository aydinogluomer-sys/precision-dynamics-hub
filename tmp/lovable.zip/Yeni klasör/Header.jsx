import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Button from './Button';
import { Icons } from '../assets/icons';
import LogoImg from '../assets/logo.png';
import './Header.css';

const navItems = [
    { label: 'Ana sayfa', path: '/', hasDropdown: false },
    {
        label: 'Hizmetler',
        path: '/hizmetler',
        hasDropdown: true,
        hasMegaMenu: true,
        isCategoryMode: true,
        children: [
            {
                label: 'Talaşlı İmalat',
                path: '/hizmetler/talasli-imalat',
                icon: Icons.cncMilling,
                links: [
                    { label: 'CNC Frezeleme', path: '/hizmetler/cnc-freze' },
                    { label: 'CNC Tornalama', path: '/hizmetler/cnc-torna' },
                    { label: 'Hassas Mikro İşleme', path: '/hizmetler/mikro-isleme' },
                    { label: 'Derin Delik & Raybalama', path: '/hizmetler/derin-delik' },
                ]
            },
            {
                label: 'Ön Üretim',
                path: '/hizmetler/on-uretim',
                icon: Icons.mold,
                links: [
                    { label: 'Enjeksiyon Kalıbı', path: '/hizmetler/on-uretim' },
                    { label: 'Basınçlı Döküm', path: '/hizmetler/on-uretim' },
                    { label: 'Silikon Kalıplama', path: '/hizmetler/on-uretim' },
                    { label: 'Fikstür & Aparat Tasarımı', path: '/hizmetler/on-uretim' },
                ]
            },
            {
                label: 'Yüzey İşlemleri',
                path: '/hizmetler/yuzey-islemleri',
                icon: Icons.processControl,
                links: [
                    { label: 'Mekanik Yüzey İşlemleri', path: '/hizmetler/yuzey-islemleri' },
                    { label: 'Anodizasyon', path: '/hizmetler/yuzey-islemleri' },
                    { label: 'Kimyasal İşlemler', path: '/hizmetler/yuzey-islemleri' },
                    { label: 'Boya & Koruyucu Kaplamalar', path: '/hizmetler/yuzey-islemleri' },
                ]
            },
            {
                label: 'İşaretleme & Tanımlama',
                path: '/hizmetler/isaretleme',
                icon: Icons.laserCutting,
                links: [
                    { label: 'Lazer Kazıma', path: '/hizmetler/isaretleme' },
                    { label: 'Tavlama', path: '/hizmetler/isaretleme' },
                    { label: 'QR & DataMatrix Kodları', path: '/hizmetler/isaretleme' },
                    { label: 'Logo & Markalama', path: '/hizmetler/isaretleme' },
                ]
            },
            {
                label: 'Montaj & Birleştirme',
                path: '/hizmetler/montaj',
                icon: Icons.production,
                links: [
                    { label: 'Insert Uygulama', path: '/hizmetler/montaj' },
                    { label: 'Mekanik Montaj', path: '/hizmetler/montaj' },
                    { label: 'Kitting & Paketleme', path: '/hizmetler/montaj' },
                    { label: 'Kaynaklı İmalat', path: '/hizmetler/montaj' },
                ]
            }
        ]
    },
    {
        label: 'Kabiliyetler',
        path: '/kabiliyetler',
        hasDropdown: true,
        hasMegaMenu: true,
        isCategoryMode: true,
        children: [
            {
                label: 'Üretim Altyapısı',
                path: '/kabiliyetler#altyapi',
                icon: Icons.production,
                links: [
                    { label: 'Makine Parkuru', path: '/kabiliyetler/makineler' },
                    { label: 'Malzeme Kütüphanesi', path: '/malzemeler' },
                ]
            },
            {
                label: 'Kalite & Standartlar',
                path: '/kabiliyetler#kalite',
                icon: Icons.precision,
                links: [
                    { label: 'Kalite Kontrol', path: '/kabiliyetler/kalite' },
                    { label: 'Tolerans & Hassasiyet', path: '/kabiliyetler/tolerans' },
                ]
            },
            {
                label: 'Mühendislik Desteği',
                path: '/kabiliyetler#muhendislik',
                icon: Icons.engineering,
                links: [
                    { label: 'Tasarım Rehberi (DFM)', path: '/dfm-rehberi' },
                    { label: 'Yüzey İşlemleri', path: '/yuzey-islemleri' },
                ]
            },
            {
                label: 'Prototipten Seri Üretime',
                path: '/kabiliyetler#prototip-seri',
                icon: Icons.mold,
                links: [
                    { label: 'Düşük Hacimli Üretim', path: '/kabiliyetler/dusuk-hacim' },
                    { label: 'Seri İmalat', path: '/kabiliyetler/seri-imalat' },
                ]
            },
            {
                label: 'Süreç & Operasyon',
                path: '/kabiliyetler#surec-yonetimi',
                icon: Icons.analysis,
                links: [
                    { label: 'Proje Yönetimi', path: '/kabiliyetler/proje-yonetimi' },
                    { label: 'Tedarik Zinciri', path: '/kabiliyetler/tedarik-zinciri' },
                    { label: 'Operasyonel Verimlilik', path: '/kabiliyetler/operasyon' },
                ]
            }
        ]
    },
    {
        label: 'Endüstriyel',
        path: '/endustriler',
        hasDropdown: true,
        hasMegaMenu: true,
        isCategoryMode: true,
        children: [
            {
                label: 'Yüksek Teknoloji',
                path: '/endustriler#yuksek-teknoloji',
                icon: Icons.aerospace,
                links: [
                    { label: 'Havacılık & Uzay', path: '/endustriler/havacilik' },
                    { label: 'Savunma Sanayi', path: '/endustriler/savunma' },
                    { label: 'Robotik', path: '/endustriler/robotik' },
                ]
            },
            {
                label: 'Seri Üretim',
                path: '/endustriler#seri-uretim',
                icon: Icons.automotive,
                links: [
                    { label: 'Otomotiv', path: '/endustriler/otomotiv' },
                    { label: 'Medikal', path: '/endustriler/medikal' },
                    { label: 'Yelken & Yat Sistemleri', path: '/endustriler/denizcilik' },
                ]
            },
            {
                label: 'Endüstriyel Sistemler',
                path: '/endustriler#sistemler',
                icon: Icons.hydraulics,
                links: [
                    { label: 'Hidrolik & Pnömatik', path: '/endustriler/hidrolik-pnomatik' },
                    { label: 'Boru & Bağlantı Parçaları', path: '/endustriler/boru-baglanti' },
                    { label: 'İklim Teknolojileri', path: '/endustriler/iklim-teknolojileri' },
                ]
            },
            {
                label: 'Üretim Çözümleri',
                path: '/uretim-cozumleri',
                icon: Icons.production,
                links: [
                    { label: 'Prototip Üretim', path: '/uretim/prototip' },
                    { label: 'Küçük Seri', path: '/uretim/kucuk-seri' },
                    { label: 'Seri Üretim', path: '/uretim/seri-uretim' },
                    { label: 'Özel Projeler', path: '/uretim/ozel-projeler' },
                ]
            },
            {
                label: 'Enerji & Altyapı',
                path: '/endustriler#enerji',
                icon: Icons.energy,
                links: [
                    { label: 'Yenilenebilir Enerji', path: '/endustriler/yenilenebilir-enerji' },
                    { label: 'Petrol & Gaz', path: '/endustriler/petrol-gaz' },
                    { label: 'Güç Dağıtım Sistemleri', path: '/endustriler/guc-dagitim' },
                    { label: 'Madencilik Ekipmanları', path: '/endustriler/madencilik' },
                ]
            }
        ]
    },
    { label: 'İletişim', path: '/iletisim', hasDropdown: false },
    { label: 'Blog', path: '/blog', hasDropdown: false },
];

function Header({ theme, toggleTheme }) {
    const [isScrolled, setIsScrolled] = useState(false);
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
    const [activeDropdown, setActiveDropdown] = useState(null);
    const location = useLocation();

    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 50);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    useEffect(() => {
        setMobileMenuOpen(false);
        setActiveDropdown(null);
    }, [location]);

    const handleDropdownEnter = (index) => {
        setActiveDropdown(index);
    };

    const handleDropdownLeave = () => {
        setActiveDropdown(null);
    };

    return (
        <header className={`header ${isScrolled ? 'header-scrolled' : ''}`}>
            <div className="header-container">
                {/* Logo */}
                <Link to="/" className="header-logo">
                    <div className="relative h-10 flex items-center mr-2">
                        <img src={LogoImg} alt="Mas Technic Logo" className="logo-img h-full w-auto object-contain" />
                    </div>

                </Link>

                {/* Desktop Navigation */}
                <nav className="header-nav" role="navigation" aria-label="Ana menü">
                    <ul className="nav-list" role="menubar">
                        {navItems.map((item, index) => (
                            <li
                                key={item.label}
                                className="nav-item"
                                role="none"
                                onMouseEnter={() => item.hasDropdown && handleDropdownEnter(index)}
                                onMouseLeave={handleDropdownLeave}
                            >
                                <Link
                                    to={item.path}
                                    className={`nav-link ${location.pathname === item.path ? 'active' : ''} ${item.label === 'Blog' ? 'nav-link-fire' : ''} ${item.label === 'Ana sayfa' ? 'nav-link-bold' : ''}`}
                                    role="menuitem"
                                    aria-haspopup={item.hasDropdown ? 'true' : undefined}
                                    aria-expanded={item.hasDropdown && activeDropdown === index ? 'true' : undefined}
                                >
                                    {item.label}
                                    {item.hasDropdown && (
                                        <span className="nav-chevron" aria-hidden="true">{Icons.chevronDown}</span>
                                    )}
                                </Link>

                                {item.hasDropdown && activeDropdown === index && (
                                    <div
                                        className={`nav-dropdown ${item.hasMegaMenu ? 'nav-dropdown-mega' : ''} ${item.isCategoryMode ? 'nav-dropdown-categories' : ''}`}
                                        role="menu"
                                        aria-label={`${item.label} alt menüsü`}
                                    >
                                        {item.isCategoryMode ? (
                                            item.children.map(category => (
                                                <div key={category.label} className="mega-menu-column">
                                                    <Link to={category.path} className="mega-column-title">
                                                        <span className="mega-column-icon">{category.icon}</span>
                                                        {category.label}
                                                    </Link>
                                                    <ul className="mega-column-list">
                                                        {category.links.map(link => (
                                                            <li key={link.label}>
                                                                <Link to={link.path} className="dropdown-link">
                                                                    {link.label}
                                                                </Link>
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </div>
                                            ))
                                        ) : (
                                            <ul className="nav-dropdown-list">
                                                {item.children.map(child => (
                                                    <li key={child.label} role="none">
                                                        <Link
                                                            to={child.path}
                                                            className="dropdown-link"
                                                            role="menuitem"
                                                        >
                                                            {child.label}
                                                        </Link>
                                                    </li>
                                                ))}
                                            </ul>
                                        )}
                                    </div>
                                )}
                            </li>
                        ))}
                    </ul>
                </nav>

                <div className="header-actions">
                    <div className="relative rfq-wrapper">
                        <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-lg blur opacity-20 dark:opacity-40 animate-pulse"></div>
                        <Button href="/teklif-al" variant="primary" size="sm" className="tech-cta relative z-10">
                            Teklif Al
                        </Button>
                    </div>

                    <Link to="/giris" className="login-btn" aria-label="Müşteri Paneli Giriş">
                        {Icons.user || <span>👤</span>}
                        <span className="login-text">Giriş</span>
                    </Link>

                    <button
                        className="theme-toggle"
                        onClick={toggleTheme}
                        aria-label={theme === 'dark' ? 'Aydınlık moda geç' : 'Karanlık moda geç'}
                    >
                        {theme === 'dark' ? Icons.sun : Icons.moon}
                    </button>

                    {/* Mobile Menu Toggle */}
                    <button
                        className="mobile-menu-toggle"
                        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                        aria-label="Menüyü aç"
                    >
                        {mobileMenuOpen ? Icons.close : Icons.menu}
                    </button>
                </div>
            </div>

            {/* Mobile Menu */}
            <div className={`mobile-menu-overlay ${mobileMenuOpen ? 'is-open' : ''}`} onClick={() => setMobileMenuOpen(false)} />

            <div className={`mobile-menu ${mobileMenuOpen ? 'is-open' : ''}`}>
                <div className="mobile-menu-inner">
                    <nav className="mobile-nav">
                        {navItems.map((item, index) => (
                            <div key={item.label} className="mobile-nav-item">
                                <div className="mobile-nav-header">
                                    <Link to={item.path} className="mobile-nav-link" onClick={() => !item.hasDropdown && setMobileMenuOpen(false)}>
                                        {item.label}
                                    </Link>
                                    {item.hasDropdown && (
                                        <button
                                            className={`mobile-submenu-toggle ${activeDropdown === index ? 'is-active' : ''}`}
                                            onClick={(e) => {
                                                e.preventDefault();
                                                setActiveDropdown(activeDropdown === index ? null : index);
                                            }}
                                            aria-label="Submenu toggle"
                                        >
                                            {Icons.chevronDown}
                                        </button>
                                    )}
                                </div>

                                {item.hasDropdown && (
                                    <div className={`mobile-nav-children ${activeDropdown === index ? 'is-open' : ''}`}>
                                        {item.children.map((child, childIdx) => (
                                            <div key={child.label} className="mobile-nav-child-group">
                                                {child.links ? (
                                                    <>
                                                        <div className="mobile-child-title">
                                                            <span className="mobile-child-icon">{child.icon}</span>
                                                            {child.label}
                                                        </div>
                                                        <div className="mobile-child-links">
                                                            {child.links.map(link => (
                                                                <Link
                                                                    key={link.label}
                                                                    to={link.path}
                                                                    className="mobile-nav-child-link"
                                                                    onClick={() => setMobileMenuOpen(false)}
                                                                >
                                                                    {link.label}
                                                                </Link>
                                                            ))}
                                                        </div>
                                                    </>
                                                ) : (
                                                    <Link
                                                        to={child.path}
                                                        className="mobile-nav-child-link"
                                                        onClick={() => setMobileMenuOpen(false)}
                                                    >
                                                        {child.label}
                                                    </Link>
                                                )}
                                            </div>
                                        ))}
                                    </div>
                                )}

                                {/* Inject Kurumsal & Destek right after Endüstriyel */}
                                {item.label === 'Endüstriyel' && (
                                    <div className="mobile-nav-item">
                                        <div className="mobile-nav-header" onClick={() => setActiveDropdown(activeDropdown === 'kurumsal' ? null : 'kurumsal')}>
                                            <div className="mobile-nav-link">Kurumsal & Destek</div>
                                            <button className={`mobile-submenu-toggle ${activeDropdown === 'kurumsal' ? 'is-active' : ''}`}>
                                                {Icons.chevronDown}
                                            </button>
                                        </div>
                                        <div className={`mobile-nav-children ${activeDropdown === 'kurumsal' ? 'is-open' : ''}`}>
                                            <div className="mobile-child-links" style={{ paddingLeft: 0 }}>
                                                {[
                                                    { label: 'Ana Sayfa', path: '/' },
                                                    { label: 'Hakkımızda', path: '/hakkimizda' },
                                                    { label: 'Teklif & Üretim Süreci', path: '/destek/uretim-sureci' },
                                                    { label: 'Kapasite', path: '/destek/kapasite' },
                                                    { label: 'Sevkiyat Standartları', path: '/destek/sevkiyat' },
                                                    { label: 'Ticari Şartlar', path: '/destek/ticari-sartlar' },
                                                    { label: 'İletişim', path: '/iletisim' },
                                                ].map(link => (
                                                    <Link
                                                        key={link.label}
                                                        to={link.path}
                                                        className="mobile-nav-child-link"
                                                        onClick={() => setMobileMenuOpen(false)}
                                                    >
                                                        {link.label}
                                                    </Link>
                                                ))}
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>
                        ))}

                        <div className="mobile-nav-extra">
                            <Link to="/iletisim" className="mobile-extra-link" onClick={() => setMobileMenuOpen(false)}>
                                {Icons.mail || Icons.phone} İletişim
                            </Link>
                        </div>
                    </nav>

                    <div className="mobile-menu-footer">
                        <div className="mobile-socials">
                            <a href="#" aria-label="LinkedIn">{Icons.linkedin}</a>
                            <a href="#" aria-label="Twitter">{Icons.twitter}</a>
                            <a href="#" aria-label="Instagram">{Icons.instagram}</a>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    );
}

export default Header;
