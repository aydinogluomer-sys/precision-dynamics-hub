import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../components/Button';
import { Icons } from '../assets/icons';
import './CapabilityPage.css';

const DeepHoleDrillingPage = () => {
    return (
        <div className="cnc-machining-page">
            {/* 1. Hero Section */}
            <section style={{
                background: 'var(--color-dark-bg)',
                color: 'white',
                padding: '100px 0 60px',
                textAlign: 'center'
            }}>
                <div className="container">
                    <h1 style={{ fontSize: '3rem', marginBottom: '16px', color: 'white' }}>Derin Delik & Raybalama</h1>
                    <p style={{ fontSize: '1.25rem', opacity: 0.8, maxWidth: '700px', margin: '0 auto' }}>
                        Boy/çap oranı yüksek deliklerde hassas ve doğrusal işleme. Hidrolik, kalıp ve makina parçaları için.
                    </p>
                </div>
            </section>

            {/* 2. Capabilities Grid */}
            <section className="section bg-white">
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Teknolojiler</span>
                        <h2>Derin Delme Kabiliyetleri</h2>
                        <div className="header-line"></div>
                        <p>Standart delme işlemlerinin ötesinde, özel derin delme çözümleri.</p>
                    </div>

                    <div className="capabilities-info">
                        <div className="capability-card" data-aos="fade-up">
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.laserCutting || '🔦'}</div>
                            <h3>Gun Drilling</h3>
                            <p>Tek dudaklı matkap ile L/D oranı 100:1'e kadar derin delikler. Yağ kanalları ve soğutma delikleri.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.1s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.precision || '🎯'}</div>
                            <h3>BTA Delme</h3>
                            <p>Büyük çaplı derin delikler için yüksek verimli BTA (Boring and Trepanning Association) sistemi.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.2s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.production || '⚙️'}</div>
                            <h3>Hassas Raybalama</h3>
                            <p>H6/H7 toleranslarında iç çap hassasiyeti. Hidrolik silindir ve rulman yatakları için ideal.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.3s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.processControl || '📊'}</div>
                            <h3>Honlama</h3>
                            <p>İç yüzeylerde Ra 0.2 μm'ye kadar yüzey kalitesi. Silindir gömlekleri ve valfler için.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* 3. Specs Section */}
            <section className="specs-section">
                <div className="specs-decor-line"></div>
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Teknik Özellikler</span>
                        <h2>Derin Delme Kapasitesi</h2>
                        <div className="header-line"></div>
                        <p>Derin delme ve raybalama operasyonları için teknik standartlarımız.</p>
                    </div>

                    <div className="specs-dashboard">
                        <div className="specs-grid-v2">
                            <div className="spec-item">
                                <span className="spec-label">Delik Çapı Aralığı</span>
                                <span className="spec-value">Ø2 mm - Ø100 mm (Gun Drill), Ø20 mm - Ø200 mm (BTA)</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Maksimum Derinlik</span>
                                <span className="spec-value">2000 mm'ye kadar (L/D oranı 100:1)</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Doğrusallık</span>
                                <span className="spec-value">0.05 mm/100 mm sapma toleransı</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Çap Toleransı</span>
                                <span className="spec-value">H6/H7 (±0.01 mm) raybalama hassasiyeti</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Yüzey Kalitesi</span>
                                <span className="spec-value">Ra 0.4 μm (delme), Ra 0.2 μm (honlama)</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Parça Ağırlığı</span>
                                <span className="spec-value">500 kg'a kadar iş parçası kapasitesi</span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* 4. Materials Mini Section */}
            <section className="section bg-soft">
                <div className="container">
                    <div className="materials-layout">
                        <div className="materials-content">
                            <span className="section-subtitle">Malzemeler</span>
                            <h2 style={{ marginBottom: '24px', fontSize: '2rem', color: 'var(--color-dark)' }}>Uyumlu Malzemeler</h2>
                            <p style={{ marginBottom: '32px', fontSize: '1.1rem', lineHeight: '1.6' }}>
                                Derin delme işlemleri için çeşitli metal ve alaşımlarda uzmanlaşmış deneyimimiz var.
                            </p>
                            <Link to="/malzemeler" className="btn-text-arrow">
                                Tüm Malzeme Listesi {Icons.arrowRight}
                            </Link>
                        </div>
                        <div className="materials-tags-cloud">
                            {['Çelik 1045', 'Çelik 4140', 'Paslanmaz 304/316', 'Alüminyum 6061', 'Alüminyum 7075', 'Titanyum', 'Bronz', 'Dökme Demir', 'İnkonel', 'Çelik Döküm'].map((mat, i) => (
                                <span key={i} className="material-tag-v2">{mat}</span>
                            ))}
                        </div>
                    </div>
                </div>
            </section>

            {/* 5. Applications Section */}
            <section className="section">
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Uygulamalar</span>
                        <h2>Derin Delme Kullanım Alanları</h2>
                        <div className="header-line"></div>
                    </div>
                    <div className="capabilities-info">
                        <div className="capability-card">
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.hydraulics || '💧'}</div>
                            <h3>Hidrolik Sistemler</h3>
                            <p>Hidrolik silindir gövdeleri, valf blokları, manifold delikleri ve yağ kanalları.</p>
                        </div>
                        <div className="capability-card">
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.mold || '🧊'}</div>
                            <h3>Kalıp & Takım</h3>
                            <p>Enjeksiyon kalıplarında soğutma kanalları, ejektör delikleri ve sıcak yolluk sistemleri.</p>
                        </div>
                        <div className="capability-card">
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.energy || '⚡'}</div>
                            <h3>Enerji & Makina</h3>
                            <p>Türbin şaftları, kompresör pistonu, pompa gövdeleri ve makina mili.</p>
                        </div>
                        <div className="capability-card">
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.defense || '🛡️'}</div>
                            <h3>Savunma</h3>
                            <p>Silah namluları, optik tüpleri ve hassas mekanik bileşenler.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* 6. FAQ Section */}
            <section className="section faq-modern">
                <div className="container">
                    <div className="section-header text-center">
                        <h2>Sık Sorulan Sorular</h2>
                    </div>
                    <div className="faq-grid-v2">
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Derin delik nedir?</h4>
                            <p>Boy/çap oranı (L/D) 10:1'den büyük delikler "derin delik" olarak tanımlanır. Standart matkaplarla bu oranlarda hassas delme mümkün değildir.</p>
                        </div>
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Gun drill ile BTA arasındaki fark nedir?</h4>
                            <p>Gun drill küçük çaplarda (Ø2-20 mm) ve yüksek L/D oranlarında kullanılır. BTA daha büyük çaplarda (Ø20 mm üstü) ve yüksek talaş kaldırma hızlarında tercih edilir.</p>
                        </div>
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Doğrusallık nasıl sağlanır?</h4>
                            <p>Özel kılavuzlama burs sistemleri, yüksek basınçlı soğutma sıvısı ve optimize edilmiş kesme parametreleri ile sapma minimuma indirilir.</p>
                        </div>
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>İç yüzey kalitesi iyileştirilebilir mi?</h4>
                            <p>Evet, raybalama ve honlama işlemleriyle Ra 0.2 μm'ye kadar yüzey kalitesi elde edilebilir. H6 toleransında çap hassasiyeti sağlanır.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* 7. Footer CTA */}
            <section className="section cnc-footer-cta">
                <div className="cta-glass-box">
                    <div className="cta-content-inner">
                        <span className="badge-outline">Derin Delme</span>
                        <h2>Derin Delik Projeniz İçin Teklif Alın</h2>
                        <p>Delik çapı, derinliği ve tolerans gereksinimlerinizi paylaşın, size en uygun çözümü sunalım.</p>
                        <Button href="/teklif-al" variant="primary" size="lg" className="btn-no-hover-color">Hemen Teklif Al</Button>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default DeepHoleDrillingPage;
