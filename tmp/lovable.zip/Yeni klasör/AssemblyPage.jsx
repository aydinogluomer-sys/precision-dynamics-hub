import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../components/Button';
import { Icons } from '../assets/icons';
import './CapabilityPage.css';

const AssemblyPage = () => {
    return (
        <div className="cnc-machining-page">
            {/* 1. Hero Section */}
            <section style={{
                background: 'var(--color-dark-bg)',
                color: 'white',
                padding: '100px 0 60px',
                textAlign: 'center'
            }}>
                <div className="container">
                    <h1 style={{ fontSize: '3rem', marginBottom: '16px', color: 'white' }}>Montaj & Sonlandırma</h1>
                    <p style={{ fontSize: '1.25rem', opacity: 0.8, maxWidth: '700px', margin: '0 auto' }}>
                        Parça üretiminden paketlenmiş son ürüne giden yol. Tek çatı altında üretim ve montaj.
                    </p>
                </div>
            </section>

            {/* 2. Capabilities Grid */}
            <section className="section bg-white">
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Hizmetler</span>
                        <h2>Montaj & Birleştirme Çözümleri</h2>
                        <div className="header-line"></div>
                        <p>Parçalarınızı kullanıma hazır ürünlere dönüştürüyoruz.</p>
                    </div>

                    <div className="capabilities-info">
                        <div className="capability-card" data-aos="fade-up">
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.tools || '🔧'}</div>
                            <h3>Insert Uygulama</h3>
                            <p>Plastik ve metal parçalara dişli insert (helikoil) montajı. Sıcak ve ultrasonik press uygulamaları.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.1s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.production || '⚙️'}</div>
                            <h3>Mekanik Montaj</h3>
                            <p>Bileşenlerin teknik resimlere uygun hassas montajı. Vidalama, perçinleme ve pres geçme işlemleri.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.2s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.shipping || '📦'}</div>
                            <h3>Kitting & Paketleme</h3>
                            <p>Montaj kitlerinin hazırlanması, özel etiketli paketleme ve sevkiyata hazır hale getirme.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.3s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon">{Icons.energy || '⚡'}</div>
                            <h3>Kaynaklı İmalat</h3>
                            <p>TIG/MIG kaynağı ile yapısal bütünleştirme. Alüminyum, çelik ve paslanmaz çelik kaynak.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* 3. Specs Section */}
            <section className="specs-section">
                <div className="specs-decor-line"></div>
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Teknik Detaylar</span>
                        <h2>Montaj Kapasitesi</h2>
                        <div className="header-line"></div>
                        <p>Profesyonel montaj altyapımızla sunduğumuz standartlar.</p>
                    </div>

                    <div className="specs-dashboard">
                        <div className="specs-grid-v2">
                            <div className="spec-item">
                                <span className="spec-label">Montaj Tipleri</span>
                                <span className="spec-value">Vidalama, perçinleme, press fit, yapıştırma ve kaynak.</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Insert Sistemleri</span>
                                <span className="spec-value">Helikoil, Keensert, PEM saplama ve press-fit somun.</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Kaynak Yöntemleri</span>
                                <span className="spec-value">TIG, MIG/MAG, Punta kaynak ve Lazer kaynağı.</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Tork Kontrolü</span>
                                <span className="spec-value">Dijital tork kontrollü vidalama, ±%5 hassasiyet.</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Test & Doğrulama</span>
                                <span className="spec-value">Fonksiyon testi, sızdırmazlık testi, elektrik testi.</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Paketleme</span>
                                <span className="spec-value">Özel köpük kalıplar, ESD koruma ve marka etiketleme.</span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* 4. Process Timeline */}
            <section className="section process-modern">
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Süreç</span>
                        <h2>Montaj İş Akışı</h2>
                        <div className="header-line"></div>
                    </div>

                    <div className="process-full-width">
                        <div className="process-timeline-v3">
                            <div className="process-step-full">
                                <div className="step-number-v3">01</div>
                                <div className="step-content-v3">
                                    <h3>Parça Teslim Alımı</h3>
                                    <p>Üretilen veya tedarik edilen tüm bileşenlerin kalite kontrolü ve envantere alınması.</p>
                                </div>
                            </div>
                            <div className="process-step-full">
                                <div className="step-number-v3">02</div>
                                <div className="step-content-v3">
                                    <h3>Alt Montaj</h3>
                                    <p>Küçük bileşenlerin alt gruplar halinde birleştirilmesi. Insert, perçin ve vidalama işlemleri.</p>
                                </div>
                            </div>
                            <div className="process-step-full">
                                <div className="step-number-v3">03</div>
                                <div className="step-content-v3">
                                    <h3>Final Montaj</h3>
                                    <p>Alt montaj gruplarının son ürün haline getirilmesi. Kaynak ve yapıştırma işlemleri.</p>
                                </div>
                            </div>
                            <div className="process-step-full">
                                <div className="step-number-v3">04</div>
                                <div className="step-content-v3">
                                    <h3>Test & Paketleme</h3>
                                    <p>Fonksiyon testleri, görsel kontrol ve sevkiyata hazır paketleme.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* 5. FAQ Section */}
            <section className="section faq-modern">
                <div className="container">
                    <div className="section-header text-center">
                        <h2>Sık Sorulan Sorular</h2>
                    </div>
                    <div className="faq-grid-v2">
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Kendi parçalarımızı da monte edebilir misiniz?</h4>
                            <p>Evet, sizin tarafınızdan sağlanan parçaları da monte edebiliriz. Parçalarınızı inceler, uygunluğunu değerlendirir ve montaj planını oluştururuz.</p>
                        </div>
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Minimum sipariş adedi var mı?</h4>
                            <p>Montaj hizmetleri için minimum adet yoktur. Prototipten seri üretime kadar her ölçekte çalışıyoruz.</p>
                        </div>
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Montaj için teslim süresi ne kadar?</h4>
                            <p>Montaj karmaşıklığına ve adet'e göre değişir. Genellikle parça üretimine ek olarak 2-5 iş günü sürer.</p>
                        </div>
                        <div className="faq-card-v2">
                            <div className="faq-q-icon">?</div>
                            <h4>Kalite kontrolü nasıl yapılıyor?</h4>
                            <p>Her montaj adımında ara kontrol yapılır. Final ürünler için fonksiyon testi, görsel muayene ve ölçüm kontrolleri uygulanır.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* 6. Footer CTA */}
            <section className="section cnc-footer-cta">
                <div className="cta-glass-box">
                    <div className="cta-content-inner">
                        <span className="badge-outline">Montaj Çözümleri</span>
                        <h2>Montaj Hattınızı Bize Taşıyın</h2>
                        <p>Üretim ve montajı tek çatı altında toplayarak sürecinizi hızlandırın ve maliyetlerinizi düşürün.</p>
                        <Button href="/teklif-al" variant="primary" size="lg" className="btn-no-hover-color">Projeyi Başlat</Button>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default AssemblyPage;
