import { Link } from 'react-router-dom';
import { Icons } from '../assets/icons';
import './CapabilitiesPage.css';

const capabilities = [
    {
        title: 'Malzeme Kütüphanesi',
        description: '50+ metal ve plastik malzeme hakkında detaylı teknik veriler, işlenebilirlik ve kullanım alanları.',
        icon: Icons.layers || Icons.fileUpload, // Fallback to fileUpload if layers missing, though layers likely intended
        path: '/malzemeler',
        color: '#2563EB'
    },
    {
        title: 'Yüzey İşlemleri',
        description: 'Parçalarınızın performansını ve estetiğini artıracak eloksal, kaplama ve boyama seçenekleri.',
        icon: Icons.processControl,
        path: '/yuzey-islemleri',
        color: '#D97706'
    },
    {
        title: 'Makine Parkuru',
        description: 'Son teknoloji 5 eksen CNC, torna ve ölçüm cihazlarımızla tanışın.',
        icon: Icons.cncMilling,
        path: '/kabiliyetler/makineler',
        color: '#059669'
    },
    {
        title: 'Tasarım Rehberi (DFM)',
        description: 'Üretilebilirlik için tasarım ipuçları ile maliyetleri düşürün ve kaliteyi artırın.',
        icon: Icons.engineering,
        path: '/dfm-rehberi',
        color: '#7C3AED'
    },
    {
        title: 'Kalite Kontrol',
        description: 'ISO 9001:2015 sertifikalı kalite yönetim sistemimiz ve CMM ölçüm yeteneklerimiz.',
        icon: Icons.check,
        path: '/kabiliyetler/kalite',
        color: '#DC2626'
    },
    {
        title: 'Tolerans & Hassasiyet',
        description: 'Mikron seviyesinde hassasiyet standartlarımız ve ulaşılabilir tolerans değerleri.',
        icon: Icons.precision,
        path: '/kabiliyetler/tolerans',
        color: '#4B5563'
    },
    // New Items from Mega Menu
    {
        title: 'Düşük Hacimli Üretim',
        description: 'Pazara giriş için ideal, kalıp maliyeti gerektirmeyen esnek üretim çözümleri.',
        icon: Icons.casting,
        path: '/kabiliyetler/dusuk-hacim',
        color: '#65A30D'
    },
    {
        title: 'Seri İmalat',
        description: 'Yüksek adetli üretimleriniz için optimize edilmiş süreçler ve rekabetçi birim maliyetler.',
        icon: Icons.production,
        path: '/kabiliyetler/seri-imalat',
        color: '#0284C7'
    },
    {
        title: 'Proje Yönetimi',
        description: 'Her projeniz için atanan uzman mühendis ile şeffaf süreç takibi ve iletişim.',
        icon: Icons.analysis,
        path: '/kabiliyetler/proje-yonetimi',
        color: '#9333EA'
    },
    {
        title: 'Tedarik Zinciri',
        description: 'Hammadde tedariğinden kapıya teslim lojistiğe kadar uçtan uca yönetim.',
        icon: Icons.delivery,
        path: '/kabiliyetler/tedarik-zinciri',
        color: '#B91C1C'
    },
    {
        title: 'Operasyonel Verimlilik',
        description: 'Yalın üretim prensipleriyle atık maliyetlerini düşürüyor, verimliliği maksimize ediyoruz.',
        icon: Icons.processControl,
        path: '/kabiliyetler/operasyon',
        color: '#0891B2'
    }
];

function CapabilitiesPage() {
    return (
        <div className="capabilities-page">
            <section style={{
                background: 'var(--color-dark-bg)', color: 'white', padding: '100px 0 60px', textAlign: 'center'
            }}>
                <div className="container">
                    <h1 style={{ fontSize: '3rem', marginBottom: '16px', color: 'white' }}>Üretim Kabiliyetlerimiz</h1>
                    <p style={{ fontSize: '1.25rem', opacity: 0.8, maxWidth: '700px', margin: '0 auto' }}>
                        Fikirlerinizi gerçeğe dönüştürmek için ihtiyacınız olan teknoloji, malzeme ve uzmanlık burada.
                    </p>
                </div>
            </section>

            <section className="section">
                <div className="container">
                    <div style={{
                        display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))', gap: '32px'
                    }}>
                        {capabilities.map((item, index) => (
                            <Link
                                key={index}
                                to={item.path}
                                style={{
                                    display: 'block', textDecoration: 'none', background: 'var(--color-white)',
                                    padding: '32px', borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)',
                                    transition: 'transform 0.3s ease, box-shadow 0.3s ease'
                                }}
                                onMouseEnter={(e) => {
                                    e.currentTarget.style.transform = 'translateY(-5px)';
                                    e.currentTarget.style.boxShadow = 'var(--shadow-xl)';
                                }}
                                onMouseLeave={(e) => {
                                    e.currentTarget.style.transform = 'translateY(0)';
                                    e.currentTarget.style.boxShadow = 'none';
                                }}
                            >
                                <div style={{
                                    width: '64px', height: '64px', borderRadius: '16px', background: `${item.color}20`,
                                    color: item.color, display: 'flex', alignItems: 'center', justifyContent: 'center',
                                    marginBottom: '24px'
                                }}>
                                    {/* Handle icon rendering carefully as Icons object might not have all keys directly */}
                                    {item.icon || <span style={{ fontSize: '24px' }}>🔧</span>}
                                </div>
                                <h3 style={{ fontSize: '1.5rem', color: 'var(--color-heading)', marginBottom: '12px' }}>
                                    {item.title}
                                </h3>
                                <p style={{ color: 'var(--color-body)', lineHeight: 1.6, margin: 0 }}>
                                    {item.description}
                                </p>
                                <div style={{ marginTop: '20px', color: item.color, fontWeight: 600, fontSize: '0.9375rem' }}>
                                    İncele &rarr;
                                </div>
                            </Link>
                        ))}
                    </div>
                </div>
            </section>

            {/* Quick CTA */}
            <section className="start-analysis-cta" style={{ padding: '60px 0', background: 'var(--color-soft-bg)', textAlign: 'center' }}>
                <div className="container">
                    <h2 style={{ marginBottom: '16px' }}>Projeniz için doğru çözümü mü arıyorsunuz?</h2>
                    <p style={{ marginBottom: '32px', color: 'var(--color-body)' }}>
                        Mühendislerimiz tasarımınızı inceleyip en uygun üretim yöntemini önersin.
                    </p>
                    <Link to="/teklif-al" className="btn btn-primary btn-lg">
                        Ücretsiz Analiz Başlat
                    </Link>
                </div>
            </section>
        </div>
    );
}

export default CapabilitiesPage;
