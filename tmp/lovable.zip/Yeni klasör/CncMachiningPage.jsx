import { Link } from 'react-router-dom';
import Button from '../components/Button';
import { Icons } from '../assets/icons';
import './CncMachiningPage.css';

const CncMachiningPage = () => {
    return (
        <div className="cnc-machining-page">
            {/* 1. Split Hero Section */}
            {/* 1. Simple Hero Section (Services Page Style) */}
            <section style={{
                background: 'var(--color-dark-bg)',
                color: 'white',
                padding: '100px 0 60px',
                textAlign: 'center'
            }}>
                <div className="container">
                    <h1 style={{ fontSize: '3rem', marginBottom: '16px', color: 'white' }}>Endüstriyel CNC İşleme</h1>
                    <p style={{ fontSize: '1.25rem', opacity: 0.8, maxWidth: '700px', margin: '0 auto' }}>
                        En karmaşık geometrileri mikron düzeyinde hassasiyetle hayata geçiriyoruz. 3, 4 ve 5 eksenli işleme merkezlerimizle üretim sınırlarını zorluyoruz.
                    </p>
                </div>
            </section>

            {/* 2. Temel Kabiliyetler */}
            <section className="section bg-white">
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Geleceğin Üretimi</span>
                        <h2>Talaşlı İmalat Kabiliyetlerimiz</h2>
                        <div className="header-line"></div>
                        <p>Modern makine parkurumuz ve uzman ekibimizle projelerinizin her aşamasındayız.</p>
                    </div>

                    <div className="capabilities-info">
                        <Link to="/hizmetler/cnc-freze" className="capability-card-link">
                            <div className="capability-card" data-aos="fade-up">
                                <div className="cap-card-bg"></div>
                                <div className="capability-icon">{Icons.cncMilling}</div>
                                <h3>CNC Frezeleme</h3>
                                <p>3-Axis ve 5-Axis (Simultane) frezeleme merkezlerimizle en karmaşık parça geometrilerinde yüksek doğruluk sunuyoruz.</p>
                                <div className="card-cta">İncele {Icons.arrowRight}</div>
                            </div>
                        </Link>
                        <Link to="/hizmetler/cnc-torna" className="capability-card-link">
                            <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.1s' }}>
                                <div className="cap-card-bg"></div>
                                <div className="capability-icon">{Icons.cncTurning}</div>
                                <h3>CNC Tornalama</h3>
                                <p>Canlı takımlı (Live Tooling) ve çok eksenli torna kabiliyetleri ile frezeleme ihtiyacını tek operasyonda çözüyoruz.</p>
                                <div className="card-cta">İncele {Icons.arrowRight}</div>
                            </div>
                        </Link>
                        <Link to="/hizmetler/mikro-isleme" className="capability-card-link">
                            <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.2s' }}>
                                <div className="cap-card-bg"></div>
                                <div className="capability-icon">{Icons.precision}</div>
                                <h3>Hassas Mikro İşleme</h3>
                                <p>Küçük çaplı, yüksek adetli ve ultra hassas mikro parçalar için optimize edilmiş üretim hatları.</p>
                                <div className="card-cta">İncele {Icons.arrowRight}</div>
                            </div>
                        </Link>
                        <Link to="/hizmetler/derin-delik" className="capability-card-link">
                            <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.3s' }}>
                                <div className="cap-card-bg"></div>
                                <div className="capability-icon">{Icons.processControl}</div>
                                <h3>Derin Delik & Raybalama</h3>
                                <p>Kritik montaj toleransları gerektiren delik işleme ve yüzey iyileştirme operasyonlarında uzmanlık.</p>
                                <div className="card-cta">İncele {Icons.arrowRight}</div>
                            </div>
                        </Link>
                    </div>
                </div>
            </section>

            {/* 3. Teknik Spesifikasyonlar */}
            <section className="section bg-white specs-section">
                <div className="specs-decor-line"></div>
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Teknik Güç</span>
                        <h2>Hassas Mühendislik<br />Limitleri</h2>
                        <div className="header-line"></div>
                        <p>Üretim standartlarımızı şeffaflıkla paylaşıyoruz.</p>
                    </div>

                    <div className="specs-container-v2">
                        <div className="specs-dashboard">
                            <div className="specs-grid-v2">
                                <div className="spec-item">
                                    <span className=
                                        "spec-label">Hassasiyet</span>
                                    <span className="spec-value">±0.005 mm (5 Mikron)</span>
                                </div>
                                <div className="spec-item">
                                    <span className="spec-label">Yüzey Kalitesi</span>
                                    <span className="spec-value">Ra 0.8 - 3.2 (Standard)</span>
                                </div>
                                <div className="spec-item">
                                    <span className="spec-label">Min. Duvar Kalınlığı</span>
                                    <span className="spec-value">0.5 mm (Metaller)</span>
                                </div>
                                <div className="spec-item">
                                    <span className="spec-label">Maks. Frezeleme</span>
                                    <span className="spec-value">1000 x 600 x 500 mm</span>
                                </div>
                                <div className="spec-item">
                                    <span className="spec-label">Maks. Tornalama</span>
                                    <span className="spec-value">Ø 350 mm Çap / 600 mm Boy</span>
                                </div>
                                <div className="spec-item">
                                    <span className="spec-label">Kalite Standartları</span>
                                    <span className="spec-value">ISO 9001, AS 9100</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* 4. İşlenen Malzeme Grupları */}
            <section className="section bg-white materials-mini-section">
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Malzeme Bilimi</span>
                        <h2>Geniş Malzeme Yelpazesi</h2>
                        <div className="header-line"></div>
                        <p>Ar-Ge çalışmalarımız sayesinde mühendislik plastiklerinden süper alaşımlara kadar her tür materyali işliyoruz.</p>
                    </div>

                    <div className="materials-tags-cloud" style={{ justifyContent: 'center', marginTop: '40px' }}>
                        {['Alüminyum 6061/7075', 'Paslanmaz Çelik (304/316)', 'Titanyum Grade 5', 'İkonel 625/718', 'Pirinç & Bakır', 'Padel (PEEK)', 'Delrin (POM)', 'Polikarbonat'].map(mat => (
                            <span key={mat} className="material-tag-v2">{mat}</span>
                        ))}
                    </div>

                    <div className="text-center" style={{ marginTop: '40px' }}>
                        <Link to="/malzemeler" className="btn-text-arrow">Tüm Malzemeleri Gör {Icons.arrowRight}</Link>
                    </div>
                </div>
            </section>

            {/* 5. Süreç Nasıl İşler? */}
            <section className="section bg-white process-modern">
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">İş Akışı</span>
                        <h2>Kesintisiz Üretim Döngüsü</h2>
                        <div className="header-line"></div>
                        <p>Fikirden nihai parçaya kadar Mas Technic disiplini ile üretim.</p>
                    </div>

                    <div className="process-full-width">
                        <div className="process-timeline-v3">
                            {[
                                { step: '01', title: 'DFM Analizi', text: '3D modelinizi yüklediğiniz anda mühendislik ekibimiz parçanızı üretilebilirlik açısından optimize eder.' },
                                { step: '02', title: 'CAM Programlama', text: 'En verimli ve güvenli kesme stratejileri belirlenerek dijital ikiz üzerinden simülasyonlar gerçekleştirilir.' },
                                { step: '03', title: 'Hassas İşleme', text: 'Yüksek hız ve tork kabiliyetine sahip CNC tezgahlarımızda parçanız mikron mikron şekillenir.' },
                                { step: '04', title: 'Kalite Doğrulama', text: 'Her parça boyutsal ve görsel testlerden geçerek %100 uygunluk garantisi ile paketlenir.' }
                            ].map((item, idx) => (
                                <div key={idx} className="process-step-full">
                                    <div className="step-number-v3">{item.step}</div>
                                    <div className="step-content-v3">
                                        <h3>{item.title}</h3>
                                        <p>{item.text}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </section>

            {/* 6. Sektörel Uygulamalar */}
            <section className="section bg-white industries-mini">
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Uzmanlık Alanları</span>
                        <h2>Kritik Sektörlere Özel Odak</h2>
                        <div className="header-line"></div>
                        <p>Kritik sektörlerin zorlu taleplerini mühendislik zekasıyla karşılıyoruz.</p>
                    </div>
                    <div className="industry-focus-grid">
                        <div className="focus-card">
                            <div className="focus-icon-box">{Icons.aerospace}</div>
                            <h4>Havacılık & Savunma</h4>
                            <p>Motor bileşenleri, aviyonik muhafazalar ve yapısal hafifletilmiş parçalar.</p>
                        </div>
                        <div className="focus-card">
                            <div className="focus-icon-box">{Icons.medical}</div>
                            <h4>Medikal Teknoloji</h4>
                            <p>Cerrahi el aletleri, titanyum implantlar ve laboratuvar ekipmanları.</p>
                        </div>
                        <div className="focus-card">
                            <div className="focus-icon-box">{Icons.robotics}</div>
                            <h4>Robotik & Otomasyon</h4>
                            <p>Mekanik kollar, eklem parçaları ve özel hassas sürücü komponentleri.</p>
                        </div>
                    </div>

                    <div className="text-center" style={{ marginTop: '50px' }}>
                        <Link to="/sektorler" className="btn-text-arrow">Tüm Sektörleri Gör {Icons.arrowRight}</Link>
                    </div>
                </div>
            </section>

            {/* 7. FAQ */}
            <section className="section bg-white faq-modern">
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Merak Edilenler</span>
                        <Link to="/sss" style={{ textDecoration: 'none', color: 'inherit' }}>
                            <h2 className="faq-link-hover">Sıkça Sorulan Sorular</h2>
                        </Link>
                        <div className="header-line"></div>
                        <p>Aklınıza takılan temel soruları burada yanıtladık.</p>
                    </div>
                    <div className="faq-grid-v2">
                        {[
                            { q: 'Minimum sipariş adedi (MOQ) var mı?', a: 'Hayır, 1 adet prototipten 10.000+ adet seri üretime kadar her ölçekte destek veriyoruz.' },
                            { q: 'Hangi dosya formatlarını tercih ediyorsunuz?', a: 'Anında analiz için STEP, IGES ve X_T formatlarını tercih ediyoruz. 2D çizimler için DXF kullanılabilir.' },
                            { q: 'Tüm yüzey işlemlerini kendiniz mi yapıyorsunuz?', a: 'Evet, eloksal, pasivasyon, kaplama ve boya dahil tüm post-process işlemlerini tek çatı altında yönetiyoruz.' },
                            { q: 'Teslimat süresi genellikle ne kadardır?', a: 'Projenin karmaşıklığına bağlı olarak, ekspres teslimatta 3-5 iş günü içinde gönderim yapabiliyoruz.' }
                        ].map((faq, i) => (
                            <div key={i} className="faq-card-v2">
                                <span className="faq-q-icon">?</span>
                                <h4>{faq.q}</h4>
                                <p>{faq.a}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* 8. Final CTA */}
            <section className="section cnc-footer-cta">
                <div className="cta-glass-box">
                    <div className="cta-content-inner">
                        <span className="badge-outline">Hemen Başlayın</span>
                        <h2>Karmaşık projelerinizi uzman ekibimize bırakın.</h2>
                        <p>3D CAD modelinizi yükleyin, üretim analinizi ve fiyatlandırmanızı dakikalar içinde görün.</p>
                        <Button href="/teklif-al" variant="primary" size="lg" className="btn-no-hover-color">Online Teklif Al</Button>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default CncMachiningPage;
