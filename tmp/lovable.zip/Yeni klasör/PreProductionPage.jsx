import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../components/Button';
import { Icons } from '../assets/icons';
import './CapabilityPage.css'; // Shared Design

const PreProductionPage = () => {
    return (
        <div className="cnc-machining-page">
            {/* 1. Simple Hero Section (Services Page Style) */}
            <section style={{
                background: 'var(--color-dark-bg)',
                color: 'white',
                padding: '100px 0 60px',
                textAlign: 'center'
            }}>
                <div className="container">
                    <h1 style={{ fontSize: '3rem', marginBottom: '16px', color: 'white' }}>Ön Üretim & Şekillendirme</h1>
                    <p style={{ fontSize: '1.25rem', opacity: 0.8, maxWidth: '700px', margin: '0 auto' }}>
                        Fikirden fiziksel forma: Seri üretimin temeli olan hassas kalıp, döküm ve ilk şekillendirme çözümleri.
                    </p>
                </div>
            </section>

            {/* 2. Key Capabilities */}
            <section className="section bg-white">
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Yetenekler</span>
                        <h2>Kalıp ve Döküm Çözümleri</h2>
                        <div className="header-line"></div>
                        <p>Plastik ve metal parçalarınız için endüstriyel üretim yöntemleri.</p>
                    </div>

                    <div className="capabilities-info">
                        <div className="capability-card" data-aos="fade-up">
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon" style={{ color: '#0688AD', background: 'rgba(6, 136, 173, 0.1)' }}>{Icons.mold || '🧊'}</div>
                            <h3>Enjeksiyon Kalıbı</h3>
                            <p>Yüksek adetli plastik parça üretimi için uzun ömürlü çelik ve alüminyum kalıplar. Otomotiv ve medikal standartlarında üretim.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.1s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon" style={{ color: '#0688AD', background: 'rgba(6, 136, 173, 0.1)' }}>{Icons.casting || '🏗️'}</div>
                            <h3>Basınçlı Döküm</h3>
                            <p>Alüminyum ve zamak parçalar için yüksek basınçlı döküm (HPDC) çözümleri. Hafiflik ve mukavemet gerektiren parçalar için ideal.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.2s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon" style={{ color: '#0688AD', background: 'rgba(6, 136, 173, 0.1)' }}>{Icons.silicone || '🔢'}</div>
                            <h3>Silikon Kalıplama</h3>
                            <p>Düşük adetli üretimler (20-50 adet) ve prototipler için hızlı vakumlu döküm (Vacuum Casting). Master modelden hassas kopyalama.</p>
                        </div>
                        <div className="capability-card" data-aos="fade-up" style={{ transitionDelay: '0.3s' }}>
                            <div className="cap-card-bg"></div>
                            <div className="capability-icon" style={{ color: '#0688AD', background: 'rgba(6, 136, 173, 0.1)' }}>{Icons.tools || '🔧'}</div>
                            <h3>Fikstür & Aparat Tasarımı</h3>
                            <p>Üretim, montaj ve kalite kontrol hatları için özel tasarım tutucu (Jig) ve fikstür imalatı.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* 3. Technical Specs / Details */}
            <section className="specs-section">
                <div className="specs-decor-line" style={{ background: 'linear-gradient(90deg, transparent, #0688AD, transparent)' }}></div>
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle" style={{ color: '#0688AD' }}>Teknik Detaylar</span>
                        <h2>Kalıp Standartlarımız</h2>
                        <div className="header-line" style={{ background: '#0688AD' }}></div>
                        <p>Uzun ömürlü ve verimli üretim için yüksek kaliteli malzemeler.</p>
                    </div>

                    <div className="specs-dashboard" style={{ borderTop: '4px solid #0688AD' }}>
                        <div className="specs-grid-v2">
                            <div className="spec-item">
                                <span className="spec-label">Kalıp Çelikleri</span>
                                <span className="spec-value">1.2344, 1.2738, 1.2083, P20 ve isteğe özel çelikler.</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Kalıp Ömrü</span>
                                <span className="spec-value">Çelik kalıplar için 1.000.000+ baskı garantisi.</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Göz Sayısı</span>
                                <span className="spec-value">Tek gözlü prototip kalıplardan çok gözlü seri üretim kalıplarına.</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Döküm Hassasiyeti</span>
                                <span className="spec-value">±0.05 mm'ye kadar hassas döküm toleransları.</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Yolluk Sistemleri</span>
                                <span className="spec-value">Sıcak yolluk (Hot Runner) ve soğuk yolluk sistemleri.</span>
                            </div>
                            <div className="spec-item">
                                <span className="spec-label">Yüzey İşlemleri</span>
                                <span className="spec-value">VDI dokulandırma, parlak polisaj ve kaplama seçenekleri.</span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* 4. Process Timeline */}
            <section className="section bg-soft process-modern">
                <div className="container">
                    <div className="section-header text-center">
                        <span className="section-subtitle">Yol Haritası</span>
                        <h2>Kalıp Üretim Süreci</h2>
                        <div className="header-line"></div>
                        <p>Tasarım onayından seri üretime şeffaf süreç yönetimi.</p>
                    </div>

                    <div className="process-full-width">
                        <div className="process-timeline-v3">
                            {[
                                { step: '01', title: 'Tasarım & DFM', text: 'Parça analizi ve kalıp tasarımı yapılır. Döküm/Enjeksiyon simülasyonları ile riskler önlenir.' },
                                { step: '02', title: 'Kalıp İşleme', text: 'Hassas CNC tezgahlarda kalıp çekirdekleri ve hamilleri işlenir (CAM & Machining).' },
                                { step: '03', title: 'Test (T1) & Alıştırma', text: 'İlk baskı numuneleri (T1) alınır, ölçüm raporları ile birlikte onayınıza sunulur.' },
                                { step: '04', title: 'Seri Üretim', text: 'Numune onayının ardından seri üretime geçilir veya kalıp tarafınıza sevk edilir.' }
                            ].map((item, idx) => (
                                <div key={idx} className="process-step-full">
                                    <div className="step-number-v3" style={{ color: '#0688AD' }}>{item.step}</div>
                                    <div className="step-content-v3">
                                        <h3>{item.title}</h3>
                                        <p>{item.text}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </section>

            {/* 5. Footer CTA */}
            <section className="section cnc-footer-cta">
                <div className="cta-glass-box">
                    <div className="cta-content-inner">
                        <span className="badge-outline" style={{ borderColor: '#0688AD', color: '#0688AD' }}>Maliyet Analizi</span>
                        <h2>Kalıp maliyetlerinizi optimize edin.</h2>
                        <p>Uzman ekibimiz DFM analizleri ile tasarımınızı üretime en uygun hale getirsin.</p>
                        <Button href="/teklif-al" variant="primary" size="lg" className="btn-no-hover-color" style={{ borderColor: '#0688AD', backgroundColor: '#0688AD' }}>Analiz Başlat</Button>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default PreProductionPage;
